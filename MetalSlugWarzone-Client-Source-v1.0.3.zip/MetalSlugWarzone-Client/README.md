# Metal Slug Warzone Client - 1.0.3

A dedicated Windows game client using Microsoft Edge WebView2. Open the application, sign in and play: no browser tabs, address bar or separate browser setup. The native window uses a compact charcoal, gold and cyan military theme with the game's original favicon.

The default entry point is **http://127.0.0.1/MetalSlugWarzone/**. Client Options can save a different local, LAN or online server origin. Every launch opens that server's `/MetalSlugWarzone/` entry point; browsing stays inside the selected game's directory.

## Upgrading from 1.0.0, 1.0.1 or 1.0.2

Close the old client before starting this build. Extract the complete new player ZIP and run its EXE; recreate your Desktop shortcut from that folder if you use one. Keep `%LOCALAPPDATA%/MetalSlugWarzone/Client` to retain your browser profiles and legacy settings. The saved server now uses a separate current-user Windows preference. See [CHANGELOG.md](CHANGELOG.md) for the high-DPI startup repair.

## For players

Use the separate **Windows x64 player ZIP**. Extract every file and open `MetalSlugWarzone.Client.exe`. `Create-Desktop-Shortcut.bat` optionally creates a shortcut with the game icon. Keep the extracted folder in place.

The default `127.0.0.1` address connects to the player's own PC, where the PHP game server must already be running. To join the online server, enter `http://metalslugwar.custom-gaming.net` in **OPTIONS**, then choose **Save and connect**. The client does not start Apache/MySQL or install the website.

- Per-monitor high DPI is enabled at startup, with automatic control scaling when moving between monitors.
- Resizable, minimizable and maximizable native window; F11 fullscreen, Escape to leave it.
- HOME returns to the landing page. RECONNECT performs a fresh GET instead of replaying a previous battle/form POST.
- OPTIONS opens inside the client window and saves a domain, IP address, HTTP/HTTPS origin and optional port. Save and connect always reconnects, including when the domain is unchanged; write errors stay visible beside the entered address. The game path is fixed to `/MetalSlugWarzone/`.
- Each server has a separate persistent WebView2 profile. Account/session lifetime is still decided by the server.
- The game's music, battle effects, saved mute preference, volume levels and track positions remain under its existing audio system.
- Friendly runtime setup and connection-recovery screens; a second launch activates the existing client.

See [the player guide](distribution/START-HERE.txt) for requirements, shortcuts and troubleshooting.

## Build with Visual Studio 2022

1. Install the **.NET desktop development** workload. Include **.NET Framework 4.8 development tools**.
2. Extract this source package and open `MetalSlugWarzone.Client.sln`.
3. Select **Release** and **x64**. Allow NuGet restore, then choose **Build Solution**.
4. Run `src/MetalSlugWarzone.Client/bin/x64/Release/net48/MetalSlugWarzone.Client.exe` with the generated files alongside it.

To build and package the complete player ZIP in one step, double-click **Build-Client.bat**. It uses VS 2022 MSBuild, verifies the required outputs, and creates `dist/MetalSlugWarzone-Client-Windows-x64.zip`. NuGet package versions and content hashes are captured in `packages.lock.json`; the script restores in locked mode.

The application targets **.NET Framework 4.8 / x64** and C# 7.3, and uses **Microsoft.Web.WebView2 1.0.4191.47**. The .NET 8 SDK is only needed for the optional independent test runners. The game server, database and uploaded website files are not part of this client build.

## Lightweight operation

The client hosts one WebView2 and relies on Microsoft's shared Evergreen runtime. It does not bundle a second Chromium distribution. GPU acceleration, normal browser caching and the game's own visibility/polling behavior are retained. There is no native refresh loop, CSS rewriting, synthetic battle action or duplicate audio player.

Actual memory use, frame rate, audio continuity and network latency depend on the device, Evergreen runtime, game page and server. A universal performance percentage is not claimed.

## Compatibility and release checks

The uploaded `MetalSlugWarzone_v0.9.0_MajorSoundSystem_Complete.zip` was inspected for PHP navigation, sessions, battles, multiplayer polling, audio and assets. Its files were not changed. The client loads the deployed game directly, so live server changes are reflected on the next page load.

The user confirmed v1.0.2 server saving works correctly. This v1.0.3 source and accompanying Windows executable have passed compilation. Navigation and XML persistence regression tests passed on .NET 8. These do not validate the Windows registry save path; that requires native Windows execution. The new high-DPI Windows checks and remaining media/multiplayer acceptance checks are listed in [WINDOWS-ACCEPTANCE.md](docs/WINDOWS-ACCEPTANCE.md); they are **pending actual Windows execution**. Build success is not a claim of completed live gameplay testing.

Read [ARCHITECTURE.md](docs/ARCHITECTURE.md), [BUILD-VERIFICATION.md](docs/BUILD-VERIFICATION.md), and [CHANGELOG.md](CHANGELOG.md) for implementation and verification details.

## Official technical references

- [Microsoft's WinForms WebView2 guide](https://learn.microsoft.com/en-us/microsoft-edge/webview2/get-started/winforms)
- [WebView2 runtime distribution](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/distribution)
- [WebView2 application security](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/security)
- [WebView2 browser flags](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/webview-features-flags)
- [.NET Framework and Windows versions](https://learn.microsoft.com/en-us/dotnet/framework/install/versions-and-dependencies)
- [Microsoft current-user preference storage](https://learn.microsoft.com/en-us/dotnet/api/microsoft.win32.registry.currentuser?view=netframework-4.8.1)
- [Pinned WebView2 SDK package](https://www.nuget.org/packages/Microsoft.Web.WebView2/1.0.4191.47)

See `THIRD_PARTY_NOTICES.txt` and the supplied Microsoft SDK license. The existing game's assets and branding retain their respective ownership.
