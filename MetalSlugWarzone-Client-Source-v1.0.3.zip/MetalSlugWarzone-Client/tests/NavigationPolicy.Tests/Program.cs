using System;
using MetalSlugWarzone.Client;

internal static class Program
{
    private static int Main()
    {
        const string root = "http://127.0.0.1/MetalSlugWarzone";
        string[] allowed =
        {
            NavigationPolicy.HomeUrl,
            root,
            root + "/index.php",
            root + "/login.php?return=index.php",
            root + "/battle.php?id=17&action=attack&token=a%2Fb%3D%3D",
            root + "/missions.php?search=Metal%20Slug+Warzone&description=a%5Cb",
            root + "/index.php?text=100%25&path=..%2f..%2f",
            root + "/index.php?redirect=https%3A%2F%2Fexample.com%2F",
            root + "/#sound-settings",
            root + "/index.php#http://example.com/",
            root + "/nested/page.php?x=1#section",
            root + "/page%20name.php",
            root + "/caf%C3%A9.php",
            "http://127.0.0.1:80/MetalSlugWarzone/",
            "HTTP://127.0.0.1/MetalSlugWarzone/index.php"
        };

        string[] blocked =
        {
            null,
            "",
            "/MetalSlugWarzone/index.php",
            "//127.0.0.1/MetalSlugWarzone/",
            "about:blank",
            "javascript:location='https://example.com'",
            "data:text/html,<h1>Other page</h1>",
            "file:///C:/MetalSlugWarzone/index.php",
            "ms-edge:" + root + "/",
            "ftp://127.0.0.1/MetalSlugWarzone/",
            "https://example.com/MetalSlugWarzone/",
            "https://127.0.0.1/MetalSlugWarzone/",
            "https://127.0.0.1:443/MetalSlugWarzone/index.php",
            "http://127.0.0.1.evil.example/MetalSlugWarzone/",
            "http://evil-127.0.0.1/MetalSlugWarzone/",
            "http://127.0.0.1./MetalSlugWarzone/",
            "http://127.0.0.1:443/MetalSlugWarzone/",
            "https://127.0.0.1:80/MetalSlugWarzone/",
            "http://127.0.0.1:8080/MetalSlugWarzone/",
            "http://127.0.0.1:080/MetalSlugWarzone/",
            "http://127.0.0.1:/MetalSlugWarzone/",
            "http://user@127.0.0.1/MetalSlugWarzone/",
            "http://user:password@127.0.0.1/MetalSlugWarzone/",
            "http://@127.0.0.1/MetalSlugWarzone/",
            "http://127.0.0.1@example.com/MetalSlugWarzone/",
            "http://127.0.0.1%40example.com/MetalSlugWarzone/",
            "http://metalslugwar\u3002custom-gaming.net/MetalSlugWarzone/",
            "http://metalslugwar.custom-gaming\uff0enet/MetalSlugWarzone/",
            "http://m\u0435talslugwar.custom-gaming.net/MetalSlugWarzone/",
            "http://127.0.0.1/",
            "http://127.0.0.1/?path=/MetalSlugWarzone/",
            "http://127.0.0.1/#/MetalSlugWarzone/",
            root + "Other/index.php",
            root + ".php",
            "http://127.0.0.1/metalslugwarzone/",
            "http://127.0.0.1//MetalSlugWarzone/",
            root + "/../index.php",
            root + "/nested/../../other.php",
            root + "/./index.php",
            root + "/nested/../index.php",
            root + "/%2e%2e/index.php",
            root + "/.%2E/index.php",
            root + "/%2E./index.php",
            root + "/%252e%252e/index.php",
            root + "/%25252e%25252e/index.php",
            root + "/..%2findex.php",
            root + "/%2f%2fexample.com/index.php",
            root + "/nested%5c..%5c..%5cindex.php",
            root + "/nested\\..\\..\\index.php",
            "http://127.0.0.1\\@example.com/MetalSlugWarzone/",
            root + "/..%20/index.php",
            root + "/.../index.php",
            root + "/..;/index.php",
            root + "/%2e%2e%3b/index.php",
            root + "/%00index.php",
            root + "/%0d%0aindex.php",
            root + "/%7findex.php",
            root + "/index.php%3f../../other.php",
            root + "/index.php%23../../other.php",
            root + "/%u002e%u002e/index.php",
            root + "/index%.php",
            root + "/index%2.php",
            root + "/index%zz.php",
            " " + root + "/",
            root + "/\n",
            root + "/index.php?x=bare space",
            "http://metal\nslugwar.custom-gaming.net/MetalSlugWarzone/",
            "http:////127.0.0.1/MetalSlugWarzone/"
        };

        var policy = new NavigationPolicy(NavigationPolicy.DefaultServerOrigin);
        int failures = 0;
        if (NavigationPolicy.HomeUrl != "http://127.0.0.1/MetalSlugWarzone/" ||
            policy.LandingUrl != "http://127.0.0.1/MetalSlugWarzone/")
        {
            Console.Error.WriteLine("The default landing URL must be the local 127.0.0.1 server.");
            failures++;
        }
        foreach (string url in allowed)
            failures += Check(policy, url, true);
        foreach (string url in blocked)
            failures += Check(policy, url, false);

        string[,] validOrigins =
        {
            { "127.0.0.1", NavigationPolicy.DefaultServerOrigin },
            { "http://metalslugwar.custom-gaming.net", "http://metalslugwar.custom-gaming.net" },
            { "HTTP://METALSLUGWAR.CUSTOM-GAMING.NET:80/", "http://metalslugwar.custom-gaming.net" },
            { "HTTP://127.0.0.1:80/", NavigationPolicy.DefaultServerOrigin },
            { "https://example.com:443", "https://example.com" },
            { "https://example.com:8443/", "https://example.com:8443" },
            { "  localhost:8080  ", "http://localhost:8080" },
            { "localhost", "http://localhost" },
            { "10.0.0.56", "http://10.0.0.56" },
            { "http://192.168.1.25:8090/", "http://192.168.1.25:8090" },
            { "[::1]:8080", "http://[::1]:8080" },
            { "https://[2001:db8::7]:9443/", "https://[2001:db8::7]:9443" },
            { "https://caf\u00e9.example", "https://xn--caf-dma.example" },
            { "http://localhost:1", "http://localhost:1" },
            { "http://localhost:65535", "http://localhost:65535" }
        };

        for (int index = 0; index < validOrigins.GetLength(0); index++)
        {
            string normalized;
            string error;
            string input = validOrigins[index, 0];
            string expected = validOrigins[index, 1];
            bool success = NavigationPolicy.TryNormalizeServerOrigin(input, out normalized, out error);
            if (!success || normalized != expected || error != null)
            {
                Console.Error.WriteLine("Origin normalization failed: " + input + " => " + normalized + " (" + error + ")");
                failures++;
                continue;
            }

            var configuredPolicy = new NavigationPolicy(input);
            if (configuredPolicy.LandingUrl != expected + "/MetalSlugWarzone/")
            {
                Console.Error.WriteLine("Incorrect landing URL for: " + input);
                failures++;
            }
            failures += Check(configuredPolicy, expected + "/MetalSlugWarzone/", true);
            failures += Check(configuredPolicy, expected + "/MetalSlugWarzone/login.php?next=index.php", true);
            failures += Check(configuredPolicy, expected + "/other-game/", false);
            failures += Check(configuredPolicy, expected + "/MetalSlugWarzone/../other-game/", false);
            if (expected != NavigationPolicy.DefaultServerOrigin)
                failures += Check(configuredPolicy, NavigationPolicy.HomeUrl, false);
        }

        string[] invalidOrigins =
        {
            null, "", " ", "http://", "https://", "file:///C:/", "ftp://example.com",
            "javascript:alert(1)", "//example.com", "http://example.com:0", "http://example.com:65536",
            "http://example.com:-1", "http://example.com:abc", "http://example.com/MetalSlugWarzone/",
            "example.com/some-path", "http://example.com/a/..", "http://example.com/./",
            "http://example.com/?a=1", "example.com?x=1", "http://example.com/#part",
            "http://user@example.com", "http://user:pass@example.com", "http://@example.com",
            "http://example.com\\@other.com", "http://exam ple.com", "http://exam\nple.com",
            "http://%65xample.com", "http://[fe80::1%25eth0]", "http://example.com.",
            "http://[::1", "http:///example.com", "http://example.com//"
        };

        foreach (string input in invalidOrigins)
        {
            string normalized;
            string error;
            if (NavigationPolicy.TryNormalizeServerOrigin(input, out normalized, out error) ||
                normalized != null || string.IsNullOrWhiteSpace(error))
            {
                Console.Error.WriteLine("Expected invalid origin: " + (input ?? "<null>"));
                failures++;
            }
            try
            {
                new NavigationPolicy(input);
                Console.Error.WriteLine("Constructor accepted invalid origin: " + (input ?? "<null>"));
                failures++;
            }
            catch (ArgumentException)
            {
                // The constructor must reject the same invalid settings input.
            }
        }

        var localPolicy = new NavigationPolicy("http://localhost:8080");
        failures += Check(localPolicy, "http://localhost/MetalSlugWarzone/", false);
        failures += Check(localPolicy, "http://127.0.0.1:8080/MetalSlugWarzone/", false);
        failures += Check(localPolicy, "https://localhost:8080/MetalSlugWarzone/", false);
        failures += Check(localPolicy, "http://localhost:8081/MetalSlugWarzone/", false);

        var securePolicy = new NavigationPolicy("https://example.com");
        failures += Check(securePolicy, "https://example.com:443/MetalSlugWarzone/index.php", true);
        failures += Check(securePolicy, "http://example.com/MetalSlugWarzone/", false);

        var onlinePolicy = new NavigationPolicy("http://metalslugwar.custom-gaming.net");
        failures += Check(onlinePolicy, "http://metalslugwar.custom-gaming.net/MetalSlugWarzone/", true);
        failures += Check(onlinePolicy, "http://metalslugwar.custom-gaming.net:80/MetalSlugWarzone/index.php", true);
        failures += Check(onlinePolicy, "HTTP://METALSLUGWAR.CUSTOM-GAMING.NET/MetalSlugWarzone/index.php", true);
        failures += Check(onlinePolicy, NavigationPolicy.HomeUrl, false);
        failures += Check(policy, "http://metalslugwar.custom-gaming.net/MetalSlugWarzone/", false);
        failures += Check(onlinePolicy, "http://metalslugwar.custom-gaming.net.evil.example/MetalSlugWarzone/", false);
        failures += Check(onlinePolicy, "http://metalslugwar.custom-gaming.net./MetalSlugWarzone/", false);
        failures += Check(onlinePolicy, "http://metalslugwar\u3002custom-gaming.net/MetalSlugWarzone/", false);
        failures += Check(onlinePolicy, "http://metalslugwar.custom-gaming\uff0enet/MetalSlugWarzone/", false);
        failures += Check(onlinePolicy, "http://m\u0435talslugwar.custom-gaming.net/MetalSlugWarzone/", false);

        Console.WriteLine("Navigation policy: " + (allowed.Length + blocked.Length) +
            " default URL cases, " + validOrigins.GetLength(0) + " valid origin suites, " +
            invalidOrigins.Length + " invalid origin suites, 16 origin isolation cases, " + failures + " failures.");
        return failures == 0 ? 0 : 1;
    }

    private static int Check(NavigationPolicy policy, string url, bool expected)
    {
        try
        {
            bool actual = policy.IsAllowed(url);
            if (actual == expected)
                return 0;

            Console.Error.WriteLine("Expected " + (expected ? "ALLOW" : "BLOCK") + ": " + (url ?? "<null>"));
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine("Unexpected exception for " + (url ?? "<null>") + ": " + exception);
        }
        return 1;
    }
}
