using System;
using System.IO;
using MetalSlugWarzone.Client;
using MetalSlugWarzone.Client.Settings;

internal static class Program
{
    private const string OnlineOrigin = "http://metalslugwar.custom-gaming.net";
    private static int cases;
    private static int assertions;
    private static int failures;

    private static int Main()
    {
        string root = Path.Combine(Path.GetTempPath(), "MetalSlugWarzone.SettingsTests." + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            Run(root, "missing-file-default", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                ClientSettings settings = ClientSettings.Load(file);
                Assert(settings.ServerOrigin == "http://127.0.0.1", "Missing settings must use the local server.");
                Assert(!File.Exists(file), "Reading missing settings must not create a file.");
            });

            Run(root, "exact-reported-domain-first-save", delegate(string folder)
            {
                string file = Path.Combine(folder, "new-folder", "settings.xml");
                var settings = new ClientSettings();
                string error;
                Assert(settings.TrySaveServerOrigin(OnlineOrigin, file, out error), "The exact reported HTTP domain must save.");
                Assert(error == null, "A successful save must clear its error.");
                Assert(File.Exists(file), "A successful first save must create the settings file.");
                Assert(settings.ServerOrigin == OnlineOrigin, "The in-memory server must change after success.");
                Assert(ClientSettings.Load(file).ServerOrigin == OnlineOrigin, "The exact domain must survive an XML reload.");
                Assert(File.ReadAllText(file).Contains("<ClientSettings"), "Use the established XML settings format.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "normalize-and-reload", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                var settings = new ClientSettings();
                string error;
                Assert(settings.TrySaveServerOrigin(" HTTP://METALSLUGWAR.CUSTOM-GAMING.NET:80/ ", file, out error), "Canonicalization must save.");
                Assert(ClientSettings.Load(file).ServerOrigin == OnlineOrigin, "Persist the canonical origin.");
            });

            Run(root, "change-existing-atomic-file", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                var settings = new ClientSettings();
                settings.Save(file);
                string before = File.ReadAllText(file);
                string error;
                Assert(settings.TrySaveServerOrigin("https://example.com:8443", file, out error), "An existing file must be replaceable.");
                Assert(File.ReadAllText(file) != before, "An origin change must update the file.");
                Assert(ClientSettings.Load(file).ServerOrigin == "https://example.com:8443", "Replacement XML must reload correctly.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "same-origin-recreates-deleted-file", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                settings.Save(file);
                File.Delete(file);
                string error;
                Assert(settings.TrySaveServerOrigin(OnlineOrigin, file, out error), "Submitting an unchanged origin must still save.");
                Assert(File.Exists(file), "An unchanged origin must recreate deleted settings.");
                Assert(ClientSettings.Load(file).ServerOrigin == OnlineOrigin, "Recreated settings must contain the submitted origin.");
            });

            Run(root, "same-origin-repairs-stale-file", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                new ClientSettings().Save(file);
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                string error;
                Assert(settings.TrySaveServerOrigin(OnlineOrigin, file, out error), "Identical input must not skip disk persistence.");
                Assert(ClientSettings.Load(file).ServerOrigin == OnlineOrigin, "The submitted origin must replace stale on-disk settings.");
            });

            Run(root, "invalid-input-preserves-settings", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                settings.Save(file);
                string before = File.ReadAllText(file);
                string error;
                Assert(!settings.TrySaveServerOrigin("http://user:secret@example.com/other-game/", file, out error), "Invalid input must be rejected.");
                Assert(settings.ServerOrigin == OnlineOrigin, "Invalid input must retain the active origin.");
                Assert(File.ReadAllText(file) == before, "Invalid input must leave the existing file untouched.");
                Assert(!string.IsNullOrWhiteSpace(error), "Invalid input needs a useful error.");
                Assert(!error.Contains("secret"), "Errors must not expose credentials from invalid input.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "destination-directory-rolls-back", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                Directory.CreateDirectory(file);
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                string error;
                Assert(!settings.TrySaveServerOrigin("https://example.com", file, out error), "A directory collision must report save failure.");
                Assert(settings.ServerOrigin == OnlineOrigin, "Failed disk persistence must roll back the in-memory server.");
                Assert(Directory.Exists(file), "A failed save must preserve the colliding directory.");
                Assert(!string.IsNullOrWhiteSpace(error), "A failed save needs actionable feedback.");
                Assert(!error.Contains(folder), "Save feedback must not disclose local paths.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "parent-file-rolls-back", delegate(string folder)
            {
                string parent = Path.Combine(folder, "blocked-parent");
                File.WriteAllText(parent, "preserve this file");
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                string error;
                Assert(!settings.TrySaveServerOrigin("https://example.com", Path.Combine(parent, "settings.xml"), out error), "An unusable parent path must report failure.");
                Assert(settings.ServerOrigin == OnlineOrigin, "Failure creating the parent must roll back the origin.");
                Assert(File.ReadAllText(parent) == "preserve this file", "The blocking file must stay intact.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "same-origin-failure-is-not-success", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                Directory.CreateDirectory(file);
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                string error;
                Assert(!settings.TrySaveServerOrigin(OnlineOrigin, file, out error), "Unchanged input must not bypass a real persistence failure.");
                Assert(settings.ServerOrigin == OnlineOrigin, "Failed unchanged input must retain the active server.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "window-placement-survives-server-save", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                var settings = new ClientSettings
                {
                    HasWindowPlacement = true, Left = -1200, Top = 75,
                    Width = 1280, Height = 720, Maximized = true
                };
                settings.Save(file);
                string error;
                Assert(settings.TrySaveServerOrigin(OnlineOrigin, file, out error), "Saving a server with window settings must succeed.");
                ClientSettings loaded = ClientSettings.Load(file);
                Assert(loaded.HasWindowPlacement && loaded.Maximized, "Preserve placement flags.");
                Assert(loaded.Left == -1200 && loaded.Top == 75, "Preserve window coordinates.");
                Assert(loaded.Width == 1280 && loaded.Height == 720, "Preserve window dimensions.");
            });

            Run(root, "malformed-xml-falls-back", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                File.WriteAllText(file, "<ClientSettings><ServerOrigin>broken");
                ClientSettings settings = ClientSettings.Load(file);
                Assert(settings.ServerOrigin == "http://127.0.0.1", "Malformed XML must fall back to the local server.");
                Assert(!settings.HasWindowPlacement, "Malformed XML must use default window placement.");
            });

            Run(root, "legacy-serializer-xml-roundtrip", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                File.WriteAllText(file,
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<ClientSettings xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\n" +
                    "  <ServerOrigin>http://metalslugwar.custom-gaming.net</ServerOrigin>\n" +
                    "  <HasWindowPlacement>true</HasWindowPlacement>\n" +
                    "  <Left>-1200</Left><Top>75</Top><Width>1280</Width><Height>720</Height>\n" +
                    "  <Maximized>true</Maximized>\n" +
                    "</ClientSettings>");
                ClientSettings loaded = ClientSettings.Load(file);
                Assert(loaded.ServerOrigin == OnlineOrigin, "Read the original XmlSerializer schema and namespace declarations.");
                Assert(loaded.HasWindowPlacement && loaded.Maximized, "Read legacy boolean fields.");
                Assert(loaded.Left == -1200 && loaded.Top == 75 && loaded.Width == 1280 && loaded.Height == 720, "Read every legacy window field.");
                loaded.Save(file);
                ClientSettings reloaded = ClientSettings.Load(file);
                Assert(reloaded.ServerOrigin == OnlineOrigin, "The explicit XML writer must preserve the legacy server through overwrite.");
                Assert(reloaded.HasWindowPlacement && reloaded.Maximized && reloaded.Left == -1200 && reloaded.Top == 75 && reloaded.Width == 1280 && reloaded.Height == 720,
                    "Every legacy window value must survive rewrite and reload.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "unknown-xml-fields-do-not-shadow-known-fields", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                File.WriteAllText(file,
                    "<ClientSettings futureVersion=\"2\">" +
                    "<FutureOptions><ServerOrigin>http://nested.example</ServerOrigin><Width>1</Width></FutureOptions>" +
                    "<ServerOrigin>http://metalslugwar.custom-gaming.net</ServerOrigin>" +
                    "<HasWindowPlacement>1</HasWindowPlacement><Left>-25</Left><Top>30</Top>" +
                    "<Width>1100</Width><Height>700</Height><Maximized>0</Maximized>" +
                    "<UnknownTail>ignored</UnknownTail></ClientSettings>");
                ClientSettings loaded = ClientSettings.Load(file);
                Assert(loaded.ServerOrigin == OnlineOrigin, "Read direct known fields despite unknown siblings or nested names.");
                Assert(loaded.HasWindowPlacement && !loaded.Maximized, "Accept XML boolean numeric forms.");
                Assert(loaded.Left == -25 && loaded.Top == 30 && loaded.Width == 1100 && loaded.Height == 700, "Unknown fields must not disturb existing window values.");
            });

            Run(root, "dtd-and-entity-expansion-denied", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                File.WriteAllText(file,
                    "<!DOCTYPE ClientSettings [<!ENTITY server \"http://metalslugwar.custom-gaming.net\">]>" +
                    "<ClientSettings><ServerOrigin>&server;</ServerOrigin><Width>1100</Width></ClientSettings>");
                ClientSettings loaded = ClientSettings.Load(file);
                Assert(loaded.ServerOrigin == NavigationPolicy.DefaultServerOrigin, "Settings containing a DTD must be rejected, without expanding entities.");
                Assert(loaded.Width == 1360, "Reject the entire DTD document and use safe defaults.");
            });

            Run(root, "failure-reports-actual-type-and-hresult", delegate(string folder)
            {
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                string error;
                Assert(!settings.TrySaveServerOrigin("https://example.com", null, out error), "A null settings path must fail persistence.");
                Assert(settings.ServerOrigin == OnlineOrigin, "Diagnostic failures must keep the previous in-memory origin.");
                Assert(error.Contains("ArgumentNullException"), "A save failure must expose its actual exception type.");
                Assert(error.Contains("0x80004003"), "A save failure must expose the actual HRESULT.");
                Assert(!error.Contains(OnlineOrigin) && !error.Contains("https://example.com"), "Diagnostic error text must not include server addresses.");
                AssertNoTemporaryFiles(folder);
            });

            Run(root, "nested-error-code-reports-root-cause", delegate(string folder)
            {
                var inner = new IOException("private diagnostic detail", unchecked((int)0x80070020));
                var outer = new InvalidOperationException("private wrapper detail", inner);
                string code = ClientLog.ErrorCode(outer);
                Assert(code == "IOException, 0x80070020", "Diagnostics must report the root exception type/HRESULT, rather than only an outer wrapper.");
                Assert(!code.Contains("private"), "Diagnostic codes must omit exception messages.");
            });

            Run(root, "invalid-saved-origin-falls-back", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                new ClientSettings { ServerOrigin = "javascript:alert(1)", Width = 1100, Height = 700 }.Save(file);
                ClientSettings loaded = ClientSettings.Load(file);
                Assert(loaded.ServerOrigin == "http://127.0.0.1", "Invalid persisted origins must fall back to the local server.");
                Assert(loaded.Width == 1100 && loaded.Height == 700, "Origin recovery must preserve valid remaining settings.");
            });

            Run(root, "restore-default-persists-localhost", delegate(string folder)
            {
                string file = Path.Combine(folder, "settings.xml");
                var settings = new ClientSettings { ServerOrigin = OnlineOrigin };
                settings.Save(file);
                string error;
                Assert(settings.TrySaveServerOrigin(NavigationPolicy.DefaultServerOrigin, file, out error), "Restoring the default must persist.");
                Assert(ClientSettings.Load(file).ServerOrigin == "http://127.0.0.1", "Restore default must persist the exact local origin.");
                Assert(new NavigationPolicy(settings.ServerOrigin).LandingUrl == "http://127.0.0.1/MetalSlugWarzone/", "Restore default must produce the local landing URL.");
            });
        }
        finally
        {
            Directory.Delete(root, true);
        }

        Console.WriteLine("Settings persistence: " + cases + " disk/diagnostic cases, " + assertions + " assertions, " + failures + " failures.");
        return failures == 0 ? 0 : 1;
    }

    private static void Run(string root, string name, Action<string> test)
    {
        cases++;
        string folder = Path.Combine(root, name);
        Directory.CreateDirectory(folder);
        try { test(folder); }
        catch (Exception error)
        {
            failures++;
            Console.Error.WriteLine(name + ": " + error);
        }
    }

    private static void Assert(bool condition, string message)
    {
        assertions++;
        if (!condition) throw new InvalidOperationException(message);
    }

    private static void AssertNoTemporaryFiles(string folder)
    {
        Assert(Directory.GetFiles(folder, "*.tmp", SearchOption.AllDirectories).Length == 0, "Persistence must clean up its temporary files.");
    }
}
