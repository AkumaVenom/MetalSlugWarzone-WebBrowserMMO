@echo off
setlocal DisableDelayedExpansion
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-Client.ps1"
if errorlevel 1 (
    echo.
    echo Build failed. See the message above.
    pause
    exit /b 1
)
echo.
pause
exit /b 0
