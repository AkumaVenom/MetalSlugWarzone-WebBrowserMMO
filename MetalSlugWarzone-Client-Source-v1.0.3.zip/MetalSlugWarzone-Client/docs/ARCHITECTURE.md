# Client architecture

## Native host

`Program.cs` starts a standard-user, single-instance WinForms application. A second launch activates its existing window. The executable is x64 and targets .NET Framework 4.8. `UI/ClientShell.cs` owns the native title bar, controls, status strip, notices, resizing, DPI layout and fullscreen state. Caption/edge bits are stripped on creation and subsequent style changes; both WM_NCCALCSIZE paths use the full client rectangle. WM_NCPAINT is handled by the custom shell and WM_NCACTIVATE uses the documented no-repaint parameter, preventing a competing native caption.

`GameClientForm.cs` creates one WebView2 using the shared stable Evergreen runtime and navigates directly to the selected server's game entry point. It does not iframe the website: the inspected PHP app sends `X-Frame-Options: DENY` and CSP `frame-ancestors 'none'`.

## DPI initialization

`HighDpi.EnableBeforeWindows()` runs at the beginning of Main, before any WinForms or WebView2 HWND exists. It requests the Windows PerMonitorV2 process default. A failed setter is harmless when the current context is already PerMonitorV2; other native error codes are logged. After WinForms initialization the actual UI-thread awareness mode is recorded. No thread-only awareness override is used.

App.config follows the documented .NET Framework WinForms section format and enables PerMonitorV2, automatic high-DPI control resizing and DPI-change messages. There is no custom configuration-section type declaration and no competing manifest DPI declaration. The window and options panel keep their 96-DPI baseline, current-monitor layout metrics and DPI-change relayout. WebView2 remains docked to its host with page zoom 1.0 so the browser handles device pixels independently of page zoom.

References: [WinForms high DPI](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/high-dpi-support-in-windows-forms), [WinForms configuration schema](https://learn.microsoft.com/en-us/dotnet/framework/configure-apps/file-schema/winforms/), [native startup DPI API](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setprocessdpiawarenesscontext).

## Server and navigation boundary

The default origin is `http://127.0.0.1`; the fixed game path is `/MetalSlugWarzone/`. Client Options is a native control panel embedded in the main window, with no separate modal Form. It accepts only an HTTP(S) origin, with optional port. Bare domains/IP addresses use HTTP. No path, credentials, query, fragment, command-line URL or ordinary address bar is accepted.

`NavigationPolicy` validates the original URL as well as its parsed URI. It rejects outside hosts/ports/schemes, authority tricks, backslashes, encoded path separators, nested percent encodings and traversal. Game pages retain their queries and fragments. Matching is case-sensitive for the game directory. HTTP and HTTPS are separate origins: a server redirecting to HTTPS must have its final HTTPS origin selected in Options.

Top-level and frame navigations are checked; network subresources are left to normal browser/CSP rules. User-initiated same-game popout links open in the current view. Other popouts, external protocols, downloads, external drops, browser history gestures/accelerators and developer tools are disabled. No general-purpose native host-object or web-message API is exposed. The initial blank document is never inserted into navigable app history by host code. HOME always uses the chosen landing URL.

## Accounts, storage and settings

`HKCU\Software\Akuma\MetalSlugWarzone\Client`, value `ServerOrigin` (REG_SZ), is the authoritative saved server preference. `ServerPreferenceStore` validates, writes, flushes and independently reopens the value to verify it. `TrySaveServerOrigin(input, out error)`, used by the actual Options panel, applies the new origin only after that succeeds; repeated selections still write and reconnect. A failure retains the active in-memory selection and the options panel, with the original exception type/HRESULT shown. Registry operation stages are logged without user data.

`%LOCALAPPDATA%/MetalSlugWarzone/Client/client-settings.xml` retains window placement and a compatibility copy of the origin. Explicit XmlReader/XmlDocument/XmlWriter handling replaces XmlSerializer code generation. Parsing prohibits DTDs and bounds input size; saves use a flushed temporary file and atomic replacement. The legacy schema still loads. The registry origin overrides this XML copy on startup. A corrupt, locked or unwritable window file does not block a verified registry save or erase its origin. If no valid registry value exists, the valid legacy origin is used; otherwise the localhost default applies.

The file-path overload of `TrySaveServerOrigin` is retained for isolated XML regression tests. It is **not** the UI save path, and Linux tests of it do not establish Windows registry behavior.

Each canonical server origin maps through SHA-256 to its own profile directory beneath `Profiles`. Switching server retires the old browser and creates a new one with the other profile; returning to a server reuses its stored data. Normal Edge browser profiles are not read or shared.

The uploaded game uses a PHP session cookie and has no implemented persistent remember-me token. Profile persistence does not extend session lifetime. No credentials or session cookies are copied into client settings. The server still owns login, account data, authorization and saves.

## Gameplay and input

The native host leaves JavaScript, GPU rendering, form submission, fetch, cookie behavior, CSS and script dialogs active. The FOB-protection confirmation requires `window.confirm`; it is preserved. Game WASD/arrows, chat typing and clipboard operations remain available.

Some `battle.php` POST responses render without redirecting. RECONNECT, F5 and Ctrl+R issue a new navigation to the allowed current URL using GET. They never call browser Reload or automatically repeat a failed POST. Recovery after browser-process failure requires a player action and starts from the landing page.

WebView2's WinForms accelerator events can block its browser thread. Keyboard-triggered navigation/resize/close work is posted back to the UI queue rather than executed inside that callback.

## Sound and lifecycle

The existing game owns HTMLAudio music, Web Audio WAV effects, volume/mute settings, replay deduplication, account revisions and playback positions. The sole added browser argument is `--autoplay-policy=no-user-gesture-required`. It permits media startup without changing the game's saved mute preference. Browser/organization policy can still affect playback; the game's existing Enable sound fallback remains available.

`audio.js` saves on link/form actions, visibility changes, pagehide and its own interval. On committed native close, browser restart or a server switch, the client dispatches the existing pagehide hook while the old game document is still alive. It waits up to 500 ms for the script call and allows a further 350 ms for queued beacons before disposal. Concurrent close/switch operations share that retirement task. The event is not sent when a player cancels the server-options panel.

This is a bounded best-effort final checkpoint, not an acknowledgement that a remote save committed. Forced process termination, server failure or loss of connectivity can prevent that checkpoint. The client does not create a second audio system or submit gameplay actions. The game's own visibility and multiplayer polling logic continues to run normally.

## Deployment and diagnosis

Ship the complete player folder: executable, configuration, managed WebView2 assemblies and x64 native loader. The shared Evergreen runtime is installed separately if missing. Native startup guidance links to Microsoft's runtime page only after the player presses GET WEBVIEW2. No runtime binary is downloaded or executed silently by this client.

`client.log` is capped at approximately 256 KiB before rotation. It records timestamps, operation labels, error types/HRESULTs, engine versions and HTTP status codes; it does not log page URLs/queries, cookies or credentials. Diagnostic messages are not uploaded by the native client.

The source package includes reproducible version references and a packaging script. The supplied executable is unsigned; the publisher can sign its release with its own certificate. The original site's favicon is embedded without visual modification.
