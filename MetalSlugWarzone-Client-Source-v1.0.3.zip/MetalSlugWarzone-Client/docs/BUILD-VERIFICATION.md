# Build verification - client 1.0.3

## Completed

- Version **1.0.3** requests PerMonitorV2 before any window is created. Native signatures and initialization order were independently source-reviewed.
- Inspected the **built EXE and generated EXE.config**: the binary includes DPI initialization/query, the configuration enables PerMonitorV2 and dynamic resizing/messages, and the custom section redeclaration is absent.
- Compared the settings, browser integration, navigation, options and shell sources against the user-accepted **v1.0.2** archive: they are byte-for-byte identical. The user confirmed domain saving works in that baseline.

- Full `MetalSlugWarzone.Client.sln` **Release | x64** rebuild using MSBuild 17.11.48, .NET SDK 8.0.425, .NET Framework 4.8 reference assemblies and the pinned WebView2 SDK.
- Final compiler result: **0 warnings, 0 errors**.
- The emitted executable is a **Windows x64 PE** using the GUI subsystem. It does not open a console window.
- The player package includes the built EXE/config, WebView2 Core/WinForms managed assemblies and matching x64 native loader.
- The final binary contains the default **`http://127.0.0.1`**. The earlier public-server default is absent from the binary.
- The original game favicon is preserved and embedded. Source ICO SHA-256: `a0eb9b03978e5f46c8b8fc17de13564b475b39210176256e41403850b78110d7`.
- Retained v1.0.2 navigation evidence (source unchanged): **83 default URL cases, 15 valid-origin suites, 32 invalid-origin suites, 16 origin-isolation cases, 0 failures**.
- Retained v1.0.2 settings persistence suite evidence (source unchanged): **19 persistence/diagnostic cases, 69 assertions, 0 failures** (18 filesystem scenarios plus one nested-error formatting check). Covers the reported online domain, overwrite and unchanged-origin writes, deleted/stale settings, failure rollback, retained window values, localhost reset, literal legacy serializer XML, unknown nested fields, DTD denial and precise exception codes.
- The rebuilt **actual v1.0.2 executable** was reflection-loaded on .NET 8/Linux: its XML first save, overwrite/reload, legacy-fixture rewrite and failure diagnostic/rollback passed. This still does not execute the Windows registry or native .NET Framework runtime.
- The v1.0.2 source review traced the actual UI save method to the verified registry preference. XML window persistence runs afterward as best effort. Startup gives a valid registry preference priority over legacy XML. The prior frame fix is retained.
- Player files have a `SHA256SUMS.txt` manifest. Both release ZIPs were checked for archive integrity and required contents.

The executable in the player ZIP is from the full MSBuild solution rebuild, not an uncompiled source stub.

## Reproduce

On Windows with Visual Studio 2022's .NET desktop development workload, run `Build-Client.bat`. The script performs a locked NuGet restore, rebuilds the solution and creates the player ZIP under `dist`.

To run the optional standalone navigation suite with the .NET 8 SDK:

```powershell
dotnet run --project tests/NavigationPolicy.Tests/NavigationPolicy.Tests.csproj -c Release
dotnet run --project tests/SettingsPersistence.Tests/SettingsPersistence.Tests.csproj -c Release
```

The test projects link the actual navigation and XML persistence source. The XML suite calls the file-path overload, not the registry-backed UI overload; its passing results cannot prove native Windows domain persistence. They have no external test-framework package dependencies. The .NET 8 test runtime is not required by players or by the .NET Framework client.

## Why the previous tests were insufficient

The v1.0.1 user screenshot shows a persistence exception. Its generic permissions message did not reveal whether serialization, temporary-file creation, flush or replacement failed. The old shipped assembly also passed a reflection-based XML save/overwrite/reload check on .NET 8/Linux, which does not reproduce .NET Framework 4.8/Windows behavior. No exact Windows exception has been established.

Version 1.0.2 bypasses that dependency for domain saving and removes XmlSerializer runtime code generation. The Options panel now displays the actual exception type/HRESULT on save failure; registry operation stages are retained in client.log. Options also displays the executable version to distinguish the new build from a still-running old copy.

## Still pending

For this release specifically, verify startup sharpness at 150% and 200% Windows scaling, moving between monitors, and Options/fullscreen/minimize after the move. The startup log should record `dpi-awareness PerMonitorV2`. These native checks cannot be executed in the Linux build environment.

The build was cross-compiled from Linux. Native Windows registry write/readback, the window, Evergreen runtime startup, sound output, multi-monitor DPI behavior and live multiplayer gameplay were not executed here. The Windows PowerShell packaging/shortcut scripts were source-reviewed; their native COM and Visual Studio execution still need a Windows PC.

Complete [WINDOWS-ACCEPTANCE.md](WINDOWS-ACCEPTANCE.md) on the intended Windows machines before describing this build as fully playtested. No universal performance, uninterrupted sound or guaranteed remote-save completion claim is made.
