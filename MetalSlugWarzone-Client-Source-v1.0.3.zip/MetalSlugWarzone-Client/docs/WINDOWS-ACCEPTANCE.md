# Windows acceptance checklist

The user confirmed v1.0.2 domain saving works correctly. For **v1.0.3**, verify sharp text/game rendering at 150% and 200% Windows scale without a compatibility override, then move the window between differently scaled monitors and reopen Options. Also check minimize/restore and fullscreen after the move.

These are the remaining manual gates. Except for the user-confirmed v1.0.2 server-save repair, these have **not** been reported as passed: this build environment cannot run the Windows WebView2 GUI. Use a test account for actions that change game state.

| Check | Expected result | Status |
|---|---|---|
| Fresh launch | Correct Metal Slug icon, styled window, exact `http://127.0.0.1/MetalSlugWarzone/` landing page; no address bar | Pending |
| Missing runtime | Useful setup screen; Microsoft download button; Try again works after installation | Pending |
| Account creation/login/logout | Standard form flow and server redirects work; no unexpected extra browser | Pending |
| Navigation barrier | No outside sites, root directory, address editing, Alt+Left/Right, mouse history gestures or file drops | Pending |
| HOME | Returns to selected server's `/MetalSlugWarzone/` entry | Pending |
| Server options | Save a LAN server, reopen client, verify saved origin and separate account/browser state; restore default | Pending |
| Persistence isolation | With the window-settings XML deliberately locked in a test profile, save the exact online origin, restart and verify the registry preference still wins | Pending |
| Invalid settings | Paths, credentials and malformed origins produce an inline error; Cancel changes nothing; Options stays inside the main window and write errors retain the entry | Pending |
| Battle reconnect | Perform one turn, then F5/Ctrl+R/RECONNECT; no repeated attack or form-resubmit prompt | Pending |
| FOB invasion | Cancel and accept the game's protection-loss confirmation; each choice behaves correctly | Pending |
| Map/multiplayer | WASD/arrows work; two accounts show expected map presence and PvP changes | Pending |
| Sound startup | Fresh unmuted account plays music; effects play during combat; no duplicate player | Pending |
| Saved sound | Mute and volume changes survive navigation/sign-in; track positions resume according to server saves | Pending |
| Minimize/restore | Game's hidden-page audio/polling behavior follows visibility; resumes after restore | Pending |
| Normal close | Close while music plays, reopen/sign in, verify a recent playback checkpoint | Pending |
| Close during server switch | No crash, hung window or duplicate audio; saved target remains selected | Pending |
| Fullscreen | F11/button fills active monitor; Escape/F11 restores previous bounds/maximized state | Pending |
| Window placement | Resize/move, close/reopen, maximize/reopen/restore; sensible bounds after monitor disconnect | Pending |
| DPI startup | Launch at 100%, 150% and 200% without a compatibility override; UI and game text render sharply, log reports PerMonitorV2 | Pending |
| DPI monitor changes | Move 100% to 150%/200% and back; reopen Options, minimize/restore and toggle fullscreen; controls remain reachable with sharp text | Pending |
| Connection loss | Useful recovery message; manual reconnect resumes GET; no auto-submitted gameplay order | Pending |
| Single instance | Second launch activates the existing client without duplicate game/audio processes | Pending |

Record Windows version, WebView2 Runtime version, scaling, server build and any observed errors when reporting results. Initial compile/navigation tests are documented separately in BUILD-VERIFICATION.md.
