# Changelog

## 1.0.3 - High DPI from Startup

- Explicitly requests PerMonitorV2 process awareness before any WinForms or WebView2 window is created, with a post-initialization DPI-mode diagnostic. An already-active PerMonitorV2 context is accepted without reporting a failure.
- Uses the documented .NET Framework WinForms configuration shape, removing the custom section-handler redeclaration and explicitly enabling dynamic control resizing and DPI-change handling.
- Retains the existing DPI-aware custom layout and native WebView2 rendering at normal page zoom.
- Version 1.0.2 domain persistence was confirmed working by the user; the accepted persistence implementation and profile locations are carried forward.
- Rebuilt the Windows x64 client. Native 150%/200% and mixed-monitor sharpness checks remain pending.

## 1.0.2 - Independent Server Preference

- Replaced domain saving through the window-settings XML file with a dedicated current-user Windows registry preference. Save and connect writes and independently rereads the value before applying it. A window-file write failure cannot veto a saved server selection.
- Reads the new preference before using the legacy XML origin; existing browser profile locations stay the same. The default remains `http://127.0.0.1/MetalSlugWarzone/`.
- Replaced runtime-generated XML serialization with explicit primitive XML reading/writing, retaining the old settings schema.
- Removed the generic permissions diagnosis. Save failures now display the original exception type and HRESULT, with open/write/flush/verify stages recorded in the local log.
- Inspected the earlier Pokémon Vortex Edge launcher: it starts Edge at a fixed URL and contains no server-preference persistence code.
- The v1.0.1 screenshot establishes a persistence failure but does not establish its underlying Windows exception. This release bypasses that XML save dependency; native Windows verification remains pending.

## 1.0.1 - Server Settings and Native Frame Repair

- Fixed Save and connect silently returning when the selected server was already saved. Every successful save now reconnects to the selected landing page.
- Replaced the separate native settings dialog with an embedded Client Options panel. The panel stays open with the entered address and an inline error if persistence fails.
- Kept the same settings file and server-specific profile locations; existing settings, cookies and account data are retained.
- Added atomic-save regression coverage for the reported online domain, replacement/repeated saves, missing or stale files, persistence failure rollback and window values.
- Prevented native caption and edge styles from being restored after style changes; handled both client-area calculation paths and native activation/paint messages to keep one custom frame.
- Preserved notice/browser state and focus beneath Client Options, including connection events that arrive while editing.
- Rebuilt Release x64 with zero warnings and zero errors. Windows visual retesting remains required for the reported frame issue.

## 1.0.0 - Dedicated Windows Client

- Introduced a native Windows x64 client built on Microsoft Edge WebView2.
- Added Metal Slug styled native window chrome, original game icon, resizing, minimizing, maximizing and fullscreen.
- Set `http://127.0.0.1/MetalSlugWarzone/` as the default startup location for distributed clients, as requested.
- Added validated, saved server-origin selection for self-hosted installations, with `/MetalSlugWarzone/` retained as the fixed game path.
- Confined navigation to the selected origin and game subtree; disabled address editing, browser history shortcuts, popouts, developer tools, file drops and downloads.
- Isolated browser data by server and retained the server's own authentication rules.
- Preserved the game's audio controls and account-backed preferences; enabled media autoplay and a bounded final sound checkpoint on ordinary close/server changes.
- Added GET-based reconnect to avoid resubmitting battle and other POST responses.
- Added startup/runtime guidance, connection errors, manual process recovery and single-instance activation.
- Added VS 2022 solution, locked SDK dependencies, player packaging/shortcut scripts, diagnostic log and Windows acceptance checklist.
- Corrected close-during-server-switch checkpoint handling and maximized-window restore placement during review.
