using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace MetalSlugWarzone.Client
{
    internal static class Program
    {
        internal static readonly int ActivateMessage = RegisterWindowMessage("MetalSlugWarzone.Client.Activate.v1");

        [STAThread]
        private static void Main()
        {
            // Set the native default before WinForms or WebView2 creates any HWND.
            HighDpi.EnableBeforeWindows();
            // No command-line URL is accepted. Server selection belongs to Client Options.
            bool created;
            using (var instance = new Mutex(true, @"Local\MetalSlugWarzone.Client.v1", out created))
            {
                if (!created)
                {
                    PostMessage(new IntPtr(0xffff), ActivateMessage, IntPtr.Zero, IntPtr.Zero);
                    return;
                }
                try
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException);
                    HighDpi.LogCurrentMode();
                    Application.Run(new GameClientForm());
                }
                catch (Exception error)
                {
                    ClientLog.Write("application", error);
                    MessageBox.Show("The client could not continue. Close it and start it again.\n\n" +
                        "If this keeps happening, send the client log to your server operator.\n" + ClientPaths.LogFile,
                        "Metal Slug Warzone", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally { instance.ReleaseMutex(); }
            }
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int RegisterWindowMessage(string name);
        [DllImport("user32.dll")]
        private static extern bool PostMessage(IntPtr handle, int message, IntPtr wParam, IntPtr lParam);
    }
}
