using System;
using System.Globalization;

namespace MetalSlugWarzone.Client
{
    /// <summary>
    /// Limits document navigation to the deployed game. This is deliberately not
    /// a subresource filter: the game may still load its images, audio and scripts.
    /// </summary>
    internal sealed class NavigationPolicy
    {
        public const string DefaultServerOrigin = "http://127.0.0.1";
        public const string HomeUrl = DefaultServerOrigin + "/MetalSlugWarzone/";
        private const string GameRoot = "/MetalSlugWarzone";
        private readonly Uri serverUri;
        private readonly string serverAuthority;
        private readonly string explicitDefaultAuthority;

        public string LandingUrl { get; private set; }

        public NavigationPolicy(string serverOrigin)
        {
            string normalized;
            string error;
            if (!TryNormalizeServerOrigin(serverOrigin, out normalized, out error))
                throw new ArgumentException(error, "serverOrigin");

            serverUri = new Uri(normalized, UriKind.Absolute);
            serverAuthority = serverUri.Authority;
            explicitDefaultAuthority = serverUri.IsDefaultPort
                ? serverAuthority + ":" + serverUri.Port.ToString(CultureInfo.InvariantCulture)
                : serverAuthority;
            LandingUrl = normalized + GameRoot + "/";
        }

        /// <summary>
        /// Accepts only a server origin. The game path is fixed by the client.
        /// A bare hostname/IP uses HTTP; explicit HTTPS is preserved.
        /// </summary>
        public static bool TryNormalizeServerOrigin(string input, out string normalized, out string error)
        {
            normalized = null;
            error = "Enter a server domain or IP address, optionally with http://, https:// and a port.";
            if (string.IsNullOrWhiteSpace(input))
                return false;

            string candidate = input.Trim();
            foreach (char character in candidate)
            {
                if (char.IsControl(character) || char.IsWhiteSpace(character) ||
                    character == '\\' || character == '%' || character == '@')
                    return false;
            }

            if (candidate.IndexOf('?') >= 0 || candidate.IndexOf('#') >= 0)
            {
                error = "Enter only the server domain and optional port, without a query or fragment.";
                return false;
            }

            if (candidate.IndexOf("://", StringComparison.Ordinal) < 0)
                candidate = "http://" + candidate;

            Uri parsed;
            if (!Uri.TryCreate(candidate, UriKind.Absolute, out parsed) ||
                (parsed.Scheme != Uri.UriSchemeHttp && parsed.Scheme != Uri.UriSchemeHttps) ||
                parsed.Port < 1 || parsed.Port > 65535 || parsed.UserInfo.Length != 0 ||
                (parsed.HostNameType != UriHostNameType.Dns &&
                 parsed.HostNameType != UriHostNameType.IPv4 &&
                 parsed.HostNameType != UriHostNameType.IPv6))
                return false;

            int authorityStart = candidate.IndexOf("://", StringComparison.Ordinal) + 3;
            int pathStart = candidate.IndexOf('/', authorityStart);
            if (pathStart >= 0 && candidate.Substring(pathStart) != "/")
            {
                error = "Enter only the server domain and optional port. The client adds /MetalSlugWarzone/ automatically.";
                return false;
            }

            if (parsed.Host.EndsWith(".", StringComparison.Ordinal))
                return false;

            try
            {
                string host = parsed.HostNameType == UriHostNameType.IPv6
                    ? "[" + parsed.DnsSafeHost.ToLowerInvariant() + "]"
                    : parsed.IdnHost.ToLowerInvariant();
                normalized = parsed.Scheme + "://" + host +
                    (parsed.IsDefaultPort ? string.Empty : ":" + parsed.Port.ToString(CultureInfo.InvariantCulture));
                error = null;
                return true;
            }
            catch (UriFormatException)
            {
                return false;
            }
        }

        public bool IsAllowed(string rawUrl)
        {
            if (string.IsNullOrEmpty(rawUrl))
                return false;

            // Browsers escape spaces in real navigation URLs. Refuse ambiguous
            // input rather than letting System.Uri trim it or remove controls.
            foreach (char character in rawUrl)
            {
                if (char.IsControl(character) || char.IsWhiteSpace(character))
                    return false;
            }

            Uri uri;
            if (!Uri.TryCreate(rawUrl, UriKind.Absolute, out uri))
                return false;

            if (!string.Equals(uri.Scheme, serverUri.Scheme, StringComparison.Ordinal) ||
                uri.Port != serverUri.Port || uri.UserInfo.Length != 0)
                return false;

            if (!string.Equals(uri.Host, serverUri.Host, StringComparison.OrdinalIgnoreCase))
                return false;

            // Validate the supplied authority too. Uri canonicalization must not
            // admit empty userinfo, Unicode hostname aliases or a trailing dot.
            int schemeEnd = rawUrl.IndexOf("://", StringComparison.Ordinal);
            if (schemeEnd < 0 ||
                !string.Equals(rawUrl.Substring(0, schemeEnd), uri.Scheme, StringComparison.OrdinalIgnoreCase))
                return false;

            int authorityStart = schemeEnd + 3;
            int authorityEnd = rawUrl.IndexOfAny(new[] { '/', '?', '#' }, authorityStart);
            if (authorityEnd < 0)
                authorityEnd = rawUrl.Length;

            string authority = rawUrl.Substring(authorityStart, authorityEnd - authorityStart);
            if (!string.Equals(authority, serverAuthority, StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(authority, explicitDefaultAuthority, StringComparison.OrdinalIgnoreCase))
                return false;

            int pathEnd = rawUrl.IndexOfAny(new[] { '?', '#' }, authorityEnd);
            if (pathEnd < 0)
                pathEnd = rawUrl.Length;

            string originalPath = rawUrl.Substring(authorityEnd, pathEnd - authorityEnd);
            if (!IsInGame(originalPath) || !IsUnambiguousPath(originalPath))
                return false;

            // Check the canonical path independently as defense in depth. Queries
            // and fragments are unrestricted game data, never navigation hosts.
            return IsInGame(uri.AbsolutePath) && IsUnambiguousPath(uri.AbsolutePath);
        }

        private static bool IsInGame(string path)
        {
            return string.Equals(path, GameRoot, StringComparison.Ordinal) ||
                path.StartsWith(GameRoot + "/", StringComparison.Ordinal);
        }

        private static bool IsUnambiguousPath(string path)
        {
            for (int index = 0; index < path.Length; index++)
            {
                if (path[index] == '\\')
                    return false;

                if (path[index] != '%')
                    continue;

                if (index + 2 >= path.Length)
                    return false;

                int high = HexValue(path[index + 1]);
                int low = HexValue(path[index + 2]);
                if (high < 0 || low < 0)
                    return false;

                int value = (high << 4) | low;
                // Deny separators, nested encoding and path/query ambiguity.
                // Ordinary encoded filename characters remain supported.
                if (value == '/' || value == '\\' || value == '%' ||
                    value == '?' || value == '#' || value <= 0x1f || value == 0x7f)
                    return false;

                index += 2;
            }

            string decodedPath = Uri.UnescapeDataString(path);
            foreach (char character in decodedPath)
            {
                if (character == '\\' || char.IsControl(character))
                    return false;
            }

            foreach (string segment in decodedPath.Split('/'))
            {
                if (segment.Length == 0)
                    continue;

                // Dot segments are rejected before Uri removes them. Trailing
                // spaces/dots and semicolons have inconsistent server handling
                // and are not part of the game's page routes.
                if (segment == "." || segment == ".." ||
                    segment.EndsWith(".", StringComparison.Ordinal) ||
                    char.IsWhiteSpace(segment[segment.Length - 1]) ||
                    segment.IndexOf(';') >= 0)
                    return false;
            }

            return true;
        }

        private static int HexValue(char value)
        {
            if (value >= '0' && value <= '9')
                return value - '0';
            if (value >= 'a' && value <= 'f')
                return value - 'a' + 10;
            if (value >= 'A' && value <= 'F')
                return value - 'A' + 10;
            return -1;
        }
    }
}
