using System;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using MetalSlugWarzone.Client.Settings;
using MetalSlugWarzone.Client.UI;

namespace MetalSlugWarzone.Client
{
    internal sealed class GameClientForm : ClientShell
    {
        private const string RuntimeDownload = "https://developer.microsoft.com/en-us/microsoft-edge/webview2/";
        private readonly ClientSettings _settings;
        private NavigationPolicy _policy;
        private WebView2 _browser;
        private bool _starting, _closing, _allowClose, _browserBroken, _hasGamePage;
        private string _currentGetUrl;
        private ulong _navigationId;
        private Icon _gameIcon;
        private Task _retirementTask = Task.CompletedTask;
        private ServerOptionsPanel _optionsPanel;
        private bool _savingServer;

        internal GameClientForm()
        {
            _settings = ClientSettings.Load();
            _policy = new NavigationPolicy(_settings.ServerOrigin);
            _currentGetUrl = _policy.LandingUrl;
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MetalSlugWarzone.Client.Assets.MetalSlugWarzone.ico"))
            {
                if (stream != null)
                {
                    using (var icon = new Icon(stream)) _gameIcon = (Icon)icon.Clone();
                    Icon = _gameIcon;
                }
            }
            _settings.ApplyWindow(this);
            HomeRequested += delegate { NavigateGet(_policy.LandingUrl); };
            ReloadRequested += delegate { Reconnect(); };
            OptionsRequested += delegate { OpenOptions(); };
            Shown += async delegate { await StartBrowserAsync(); };
            FormClosing += ClosingClient;
        }

        private async Task StartBrowserAsync()
        {
            if (_starting || _closing || IsDisposed) return;
            _starting = true;
            SetBusy(true);
            SetStatus("Starting your game client...");
            ShowNotice("REPORTING FOR DUTY", "Preparing your connection to the Warzone command network.", null, null);
            try
            {
                await RetireBrowserAsync();
                if (_closing) return;
                _policy = new NavigationPolicy(_settings.ServerOrigin);
                _currentGetUrl = _policy.LandingUrl;
                _hasGamePage = false;
                _browserBroken = false;

                var options = new CoreWebView2EnvironmentOptions("--autoplay-policy=no-user-gesture-required")
                {
                    ReleaseChannels = CoreWebView2ReleaseChannels.Stable,
                    ExclusiveUserDataFolderAccess = true
                };
                // Evergreen uses Microsoft's shared runtime. Cookies and storage belong
                // to this client and selected server, never to a normal Edge profile.
                var environment = await CoreWebView2Environment.CreateAsync(null,
                    ClientPaths.ProfileFor(_settings.ServerOrigin), options);
                if (_closing) return;

                var browser = new WebView2
                {
                    Dock = DockStyle.Fill,
                    DefaultBackgroundColor = Color.FromArgb(11, 12, 13),
                    AllowExternalDrop = false,
                    TabIndex = 0
                };
                _browser = browser;
                BrowserHost.Controls.Add(browser);
                await browser.EnsureCoreWebView2Async(environment);
                if (_closing || !ReferenceEquals(browser, _browser)) return;

                ConfigureBrowser(browser);
                browser.ZoomFactor = 1.0;
                browser.CoreWebView2.Navigate(_policy.LandingUrl);
                ClientLog.Write("browser-ready " + environment.BrowserVersionString);
            }
            catch (WebView2RuntimeNotFoundException error)
            {
                if (_closing) return;
                ClientLog.Write("runtime-missing", error);
                SetBusy(false);
                SetStatus("A one-time Microsoft runtime setup is needed.", true);
                ShowNotice("ONE LAST THING", "Install Microsoft's free Evergreen WebView2 Runtime, then choose Try again. Your game client uses this shared Edge engine.",
                    "GET WEBVIEW2", OpenRuntimeDownload, "TRY AGAIN", Reconnect);
            }
            catch (Exception error)
            {
                if (_closing) return;
                ClientLog.Write("browser-start", error);
                _browserBroken = true;
                SetBusy(false);
                SetStatus("The client could not start the game view.", true);
                ShowNotice("CLIENT NEEDS ATTENTION", "Close other copies of this client and try again. If the problem continues, install or update the Evergreen WebView2 Runtime. Your saved server settings are retained.",
                    "TRY AGAIN", Reconnect, "GET WEBVIEW2", OpenRuntimeDownload);
            }
            finally { _starting = false; }
        }

        private void ConfigureBrowser(WebView2 browser)
        {
            CoreWebView2 core = browser.CoreWebView2;
            CoreWebView2Settings settings = core.Settings;
            settings.IsScriptEnabled = true;
            settings.AreDefaultScriptDialogsEnabled = true; // FOB invasion uses window.confirm.
            settings.AreDefaultContextMenusEnabled = false;
            settings.AreDevToolsEnabled = false;
            settings.AreBrowserAcceleratorKeysEnabled = false;
            settings.IsStatusBarEnabled = false;
            settings.IsBuiltInErrorPageEnabled = false;
            settings.IsZoomControlEnabled = false;
            settings.IsPinchZoomEnabled = false;
            settings.IsSwipeNavigationEnabled = false;
            settings.AreHostObjectsAllowed = false;
            settings.IsWebMessageEnabled = false;

            core.NavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e)
            {
                if (!IsCurrent(browser) || !_policy.IsAllowed(e.Uri))
                {
                    e.Cancel = true;
                    if (IsCurrent(browser))
                    {
                        SetStatus("This client stays inside the selected Warzone server.", true);
                        if (!_hasGamePage)
                        {
                            SetBusy(false);
                            ShowNotice("GAME ADDRESS ONLY", "That page is outside the selected server's Metal Slug Warzone area. Return home, or select your server in Client Options.",
                                "RETURN HOME", delegate { NavigateGet(_policy.LandingUrl); }, "CLIENT OPTIONS", OpenOptions);
                        }
                    }
                    return;
                }
                _navigationId = e.NavigationId;
                _currentGetUrl = e.Uri;
                SetBusy(true);
                SetStatus("Connecting to the command network...");
            };

            core.FrameNavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e)
            {
                // The supplied game has no frames. Never allow a frame to become a second browser.
                if (!IsCurrent(browser) || !_policy.IsAllowed(e.Uri)) e.Cancel = true;
            };
            core.NavigationCompleted += delegate(object sender, CoreWebView2NavigationCompletedEventArgs e)
            {
                if (!IsCurrent(browser) || e.NavigationId != _navigationId) return;
                SetBusy(false);
                if (!e.IsSuccess)
                {
                    if (e.WebErrorStatus == CoreWebView2WebErrorStatus.OperationCanceled) return;
                    ClientLog.Write("navigation-error " + e.WebErrorStatus);
                    ShowConnectionError(e.WebErrorStatus.ToString().StartsWith("Certificate", StringComparison.Ordinal)
                        ? "The server's HTTPS certificate could not be verified. Ask the server operator to correct it, then reconnect."
                        : "The command network could not be reached. Check your connection and that the selected game server is running, then reconnect.");
                    return;
                }
                if (e.HttpStatusCode >= 400)
                {
                    ClientLog.Write("server-http " + e.HttpStatusCode);
                    ShowConnectionError("The game server returned an error (HTTP " + e.HttpStatusCode + "). Check your server address or try again shortly.");
                    return;
                }
                if (!_policy.IsAllowed(core.Source)) return;
                _hasGamePage = true;
                _currentGetUrl = core.Source;
                HideNotice();
                SetStatus("Ready for deployment  |  Sound controls are inside the game  |  F11 fullscreen");
            };
            core.NewWindowRequested += delegate(object sender, CoreWebView2NewWindowRequestedEventArgs e)
            {
                e.Handled = true;
                if (!IsCurrent(browser)) return;
                if (e.IsUserInitiated && _policy.IsAllowed(e.Uri))
                {
                    string target = e.Uri;
                    QueueUi(delegate { NavigateGet(target); });
                }
                else SetStatus("Outside links and additional browser windows are disabled.", true);
            };
            core.DownloadStarting += delegate(object sender, CoreWebView2DownloadStartingEventArgs e)
            {
                e.Cancel = true;
                if (IsCurrent(browser)) SetStatus("This client is for playing Metal Slug Warzone; downloads are disabled.", true);
            };
            core.PermissionRequested += delegate(object sender, CoreWebView2PermissionRequestedEventArgs e)
            {
                // Current game needs neither device capture, location nor native privileges.
                e.State = CoreWebView2PermissionState.Deny;
            };
            core.ServerCertificateErrorDetected += delegate(object sender, CoreWebView2ServerCertificateErrorDetectedEventArgs e)
            {
                e.Action = CoreWebView2ServerCertificateErrorAction.Cancel;
            };
            core.ProcessFailed += delegate(object sender, CoreWebView2ProcessFailedEventArgs e)
            {
                if (!IsCurrent(browser)) return;
                ClientLog.Write("browser-process " + e.ProcessFailedKind);
                if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.BrowserProcessExited ||
                    e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessExited ||
                    e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessUnresponsive)
                {
                    _browserBroken = true;
                    ShowConnectionError("The game view stopped responding. Reconnect to open the landing page again. Any completed actions remain on the server.");
                }
                // GPU/utility subprocesses are recovered by WebView2 itself.
            };
            core.WindowCloseRequested += delegate { if (IsCurrent(browser)) QueueUi(Close); };
            browser.KeyDown += BrowserKeyDown;
        }

        private bool IsCurrent(WebView2 browser)
        {
            return !_closing && !IsDisposed && ReferenceEquals(_browser, browser) && !browser.IsDisposed;
        }

        private void BrowserKeyDown(object sender, KeyEventArgs e)
        {
            // WebView2 blocks its browser thread during accelerator callbacks.
            // Handle immediately, then post native/browser work back to the UI queue.
            Action action = null;
            if (e.KeyData == Keys.F11) action = ToggleFullscreen;
            else if (e.KeyCode == Keys.Escape && IsFullscreen) action = ExitFullscreen;
            else if (e.KeyData == Keys.F5 || e.KeyData == (Keys.Control | Keys.R) || e.KeyData == (Keys.Control | Keys.F5)) action = Reconnect;
            else if (e.KeyData == (Keys.Alt | Keys.Home)) action = delegate { NavigateGet(_policy.LandingUrl); };
            else if (e.KeyData == (Keys.Alt | Keys.F4)) action = Close;
            bool blocked = IsBrowserOnlyShortcut(e.KeyData);
            if (action == null && !blocked) return; // Leave movement, chat, copy/paste and form keys intact.
            e.Handled = true;
            e.SuppressKeyPress = true;
            if (action != null) QueueUi(action);
        }

        private static bool IsBrowserOnlyShortcut(Keys keys)
        {
            return keys == (Keys.Alt | Keys.Left) || keys == (Keys.Alt | Keys.Right) ||
                keys == Keys.BrowserBack || keys == Keys.BrowserForward || keys == Keys.BrowserHome ||
                keys == (Keys.Control | Keys.L) || keys == (Keys.Alt | Keys.D) || keys == Keys.F6 ||
                keys == Keys.F12 || keys == (Keys.Control | Keys.Shift | Keys.I) ||
                keys == (Keys.Control | Keys.Shift | Keys.J) || keys == (Keys.Control | Keys.Shift | Keys.C) ||
                keys == (Keys.Control | Keys.N) || keys == (Keys.Control | Keys.T) ||
                keys == (Keys.Control | Keys.O) || keys == (Keys.Control | Keys.P) || keys == (Keys.Control | Keys.S) ||
                keys == (Keys.Control | Keys.U);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (IsClientOverlayVisible) return base.ProcessCmdKey(ref msg, keyData);
            if (IsBrowserOnlyShortcut(keyData)) return true;
            if (keyData == Keys.F5 || keyData == (Keys.Control | Keys.F5)) { QueueUi(Reconnect); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void QueueUi(Action action)
        {
            if (_closing || IsDisposed || !IsHandleCreated) return;
            BeginInvoke(new Action(delegate { if (!_closing && !IsDisposed) action(); }));
        }

        private void NavigateGet(string target)
        {
            if (_starting || _closing || !_policy.IsAllowed(target)) return;
            if (_browser == null || _browser.CoreWebView2 == null || _browserBroken) { Reconnect(); return; }
            try
            {
                // An explicit GET avoids re-submitting a battle/form POST response.
                _browser.CoreWebView2.Navigate(target);
            }
            catch (Exception error)
            {
                ClientLog.Write("navigate", error);
                _browserBroken = true;
                ShowConnectionError("The game view needs to be restarted. Choose Reconnect to return to the game.");
            }
        }

        private async void Reconnect()
        {
            if (_starting || _closing) return;
            if (_browser == null || _browser.CoreWebView2 == null || _browserBroken) await StartBrowserAsync();
            else NavigateGet(_policy.IsAllowed(_currentGetUrl) ? _currentGetUrl : _policy.LandingUrl);
        }

        private void ShowConnectionError(string message)
        {
            SetBusy(false);
            SetStatus("Command link interrupted. Your completed progress stays on the server.", true);
            ShowNotice("CONNECTION INTERRUPTED", message + "\n\nSelected server: " + _settings.ServerOrigin,
                "RECONNECT", Reconnect, "CLIENT OPTIONS", OpenOptions);
        }

        private void OpenOptions()
        {
            if (_optionsPanel != null)
            {
                _optionsPanel.FocusServerInput();
                return;
            }
            if (_starting || _closing)
            {
                if (!_closing) SetStatus("The client is starting. Open Options again in a moment.");
                return;
            }
            var panel = new ServerOptionsPanel(_settings.ServerOrigin);
            _optionsPanel = panel;
            panel.CancelRequested += delegate { CloseOptions(); };
            panel.SaveRequested += origin => SaveServerSelection(panel, origin);
            ShowClientOverlay(panel);
            panel.FocusServerInput();
        }

        private void CloseOptions()
        {
            var panel = _optionsPanel;
            if (panel == null) return;
            _optionsPanel = null;
            HideClientOverlay();
            panel.Dispose();
        }

        private async void SaveServerSelection(ServerOptionsPanel panel, string origin)
        {
            if (_savingServer || _closing || !ReferenceEquals(_optionsPanel, panel)) return;
            _savingServer = true;
            try
            {
                string error;
                if (!_settings.TrySaveServerOrigin(origin, out error))
                {
                    panel.ShowSaveError(error);
                    return;
                }
                // Save and connect is always an action, including the already-selected
                // origin after a failed connection. Close settings only after verified preference persistence.
                CloseOptions();
                SetStatus("Server saved. Connecting to your game...");
                await StartBrowserAsync();
            }
            finally { _savingServer = false; }
        }

        private void OpenRuntimeDownload()
        {
            try { Process.Start(new ProcessStartInfo(RuntimeDownload) { UseShellExecute = true }); }
            catch (Exception error)
            {
                ClientLog.Write("runtime-download-page", error);
                MessageBox.Show(this, "Open Microsoft's WebView2 download page in your regular browser and install the Evergreen Runtime:\n\n" + RuntimeDownload,
                    "WebView2 setup", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private Task RetireBrowserAsync()
        {
            // Closing can arrive while a server switch is already draining a view.
            // Both callers must await the same retirement before the form is disposed.
            if (!_retirementTask.IsCompleted) return _retirementTask;
            WebView2 old = _browser;
            if (old == null) return Task.CompletedTask;
            _browser = null; // Ignore stale callbacks while this view is leaving.
            _retirementTask = RetireOneBrowserAsync(old, _policy, _browserBroken);
            return _retirementTask;
        }

        private async Task RetireOneBrowserAsync(WebView2 old, NavigationPolicy oldPolicy, bool broken)
        {
            try
            {
                if (!old.IsDisposed && old.CoreWebView2 != null && !broken && oldPolicy.IsAllowed(old.CoreWebView2.Source))
                {
                    // The inspected game's private sound system already owns pagehide:
                    // checkpoint, sendBeacon/keepalive, pause, and release its audio lease.
                    Task flush = old.CoreWebView2.ExecuteScriptAsync(
                        "window.dispatchEvent(new PageTransitionEvent('pagehide', { persisted: false }));");
                    Task completed = await Task.WhenAny(flush, Task.Delay(500));
                    if (completed == flush) await flush;
                    else ObserveFault(flush);
                    await Task.Delay(350); // Bounded best-effort drain; never freeze close on the network.
                }
            }
            catch (Exception error) { ClientLog.Write("close-checkpoint", error); }
            finally
            {
                if (!BrowserHost.IsDisposed) BrowserHost.Controls.Remove(old);
                old.Dispose();
            }
        }

        private static void ObserveFault(Task task)
        {
            task.ContinueWith(t => { var ignored = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
        }

        private async void ClosingClient(object sender, FormClosingEventArgs e)
        {
            if (_allowClose) return;
            e.Cancel = true;
            if (_closing) return;
            _closing = true;
            SetBusy(true);
            SetStatus("Closing your game session...");
            try
            {
                // Persist the normal desktop placement, not fullscreen monitor bounds.
                if (IsFullscreen) ExitFullscreen();
                _settings.CaptureWindow(this);
                try { _settings.Save(); }
                catch (Exception error) { ClientLog.Write("window-settings-save", error); }
                await RetireBrowserAsync();
            }
            finally
            {
                _allowClose = true;
                Close();
            }
        }

        protected override void WndProc(ref Message message)
        {
            if (message.Msg == Program.ActivateMessage && !_closing)
            {
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                Show();
                Activate();
            }
            base.WndProc(ref message);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_optionsPanel != null) { _optionsPanel.Dispose(); _optionsPanel = null; }
                if (_browser != null) { _browser.Dispose(); _browser = null; }
            }
            base.Dispose(disposing);
            if (disposing && _gameIcon != null) { _gameIcon.Dispose(); _gameIcon = null; }
        }
    }
}
