using System;
using System.Drawing;
using System.Windows.Forms;

namespace MetalSlugWarzone.Client.Settings
{
    /// <summary>
    /// In-client server options. The owner persists and connects after
    /// SaveRequested, and removes this panel only when that operation succeeds.
    /// </summary>
    public sealed class ServerOptionsPanel : UserControl
    {
        private static readonly Color BackgroundColor = Color.FromArgb(17, 21, 23);
        private static readonly Color SurfaceColor = Color.FromArgb(27, 34, 36);
        private static readonly Color TextColor = Color.FromArgb(237, 231, 214);
        private static readonly Color MutedColor = Color.FromArgb(173, 185, 180);
        private static readonly Color GoldColor = Color.FromArgb(233, 184, 85);
        private static readonly Color CyanColor = Color.FromArgb(118, 201, 201);

        private readonly TableLayoutPanel content;
        private readonly TableLayoutPanel actions;
        private readonly TextBox originInput;
        private readonly Label validationLabel;
        private readonly Button resetButton;
        private readonly Button cancelButton;
        private readonly Button saveButton;
        private readonly Font headingFont;
        private readonly Font kickerFont;
        private bool layoutReady;
        private bool arranging;
        private bool compactActions;
        private bool resourcesDisposed;

        public event Action<string> SaveRequested;
        public event EventHandler CancelRequested;

        public ServerOptionsPanel(string currentOrigin)
        {
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = SystemFonts.MessageBoxFont;
            headingFont = new Font(Font.FontFamily, 17F, FontStyle.Bold);
            kickerFont = new Font(Font.FontFamily, 9F, FontStyle.Bold);
            BackColor = BackgroundColor;
            ForeColor = TextColor;
            Dock = DockStyle.Fill;
            AutoScroll = true;
            TabStop = false;
            AccessibleName = "Metal Slug Warzone server settings";

            content = new TableLayoutPanel
            {
                BackColor = BackgroundColor,
                AutoSize = false,
                ColumnCount = 1,
                RowCount = 9,
                Margin = Padding.Empty,
                Padding = new Padding(24),
                TabIndex = 0,
                TabStop = false
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            for (int row = 0; row < content.RowCount; row++)
                content.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var version = typeof(ServerOptionsPanel).Assembly.GetName().Version.ToString(3);
            var kicker = MakeLabel("CLIENT OPTIONS  /  v" + version, CyanColor, new Padding(0, 0, 0, 5));
            kicker.Font = kickerFont;
            content.Controls.Add(kicker, 0, 0);

            var heading = MakeLabel("SERVER SETTINGS", GoldColor, new Padding(0, 0, 0, 15));
            heading.Font = headingFont;
            content.Controls.Add(heading, 0, 1);

            content.Controls.Add(MakeLabel(
                "Choose your game server. Save and connect saves this address and opens its Metal Slug Warzone game.",
                TextColor, new Padding(0, 0, 0, 17)), 0, 2);

            var inputLabel = MakeLabel("&Server domain or IP address", TextColor, new Padding(0, 0, 0, 6));
            inputLabel.UseMnemonic = true;
            inputLabel.TabIndex = 0;
            content.Controls.Add(inputLabel, 0, 3);

            originInput = new TextBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(9, 14, 16),
                ForeColor = TextColor,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(0, 0, 0, 9),
                MaxLength = 2048,
                Multiline = false,
                TabIndex = 1,
                AccessibleName = "Server domain or IP address",
                AccessibleDescription = "Enter a domain or IP address, optionally with HTTP, HTTPS or a port. The game path is fixed.",
                Text = string.IsNullOrWhiteSpace(currentOrigin)
                    ? NavigationPolicy.DefaultServerOrigin
                    : currentOrigin
            };
            content.Controls.Add(originInput, 0, 4);

            content.Controls.Add(MakeLabel(
                "The client adds /MetalSlugWarzone/ automatically. Enter only the domain or IP address and optional port.",
                CyanColor, new Padding(0, 0, 0, 13)), 0, 5);

            content.Controls.Add(MakeLabel(
                "Each server keeps separate sign-in and browser data. Changing server does not transfer your account or progress.",
                MutedColor, new Padding(0, 0, 0, 9)), 0, 6);

            validationLabel = MakeLabel(string.Empty, Color.FromArgb(247, 156, 138), new Padding(0, 0, 0, 6));
            validationLabel.AccessibleName = "Server settings message";
            validationLabel.MinimumSize = new Size(0, 32);
            content.Controls.Add(validationLabel, 0, 7);

            actions = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = false,
                Margin = new Padding(0, 12, 0, 0),
                Padding = Padding.Empty,
                TabIndex = 2,
                TabStop = false
            };

            resetButton = MakeButton("&Restore default", CyanColor);
            resetButton.TabIndex = 0;
            resetButton.Click += delegate { ResetToDefault(); };

            cancelButton = MakeButton("&Cancel", MutedColor);
            cancelButton.TabIndex = 1;
            cancelButton.Click += delegate { RequestCancel(); };

            saveButton = MakeButton("Save and c&onnect", GoldColor);
            saveButton.TabIndex = 2;
            saveButton.Click += delegate { RequestSave(); };

            content.Controls.Add(actions, 0, 8);
            ConfigureActionLayout(false);
            Controls.Add(content);
            originInput.TextChanged += delegate
            {
                validationLabel.Text = string.Empty;
                ArrangeContent();
            };
            layoutReady = true;
            ArrangeContent();
        }

        public void FocusServerInput()
        {
            if (IsDisposed) return;
            originInput.Focus();
            originInput.SelectAll();
            ScrollControlIntoView(originInput);
        }

        public void ShowSaveError(string message)
        {
            if (IsDisposed) return;
            string safeMessage = string.IsNullOrWhiteSpace(message)
                ? "The server could not be saved. Check the address and try Save and connect again."
                : message.Trim();
            validationLabel.Text = safeMessage.Length > 280
                ? safeMessage.Substring(0, 277) + "..."
                : safeMessage;
            ArrangeContent();
            ScrollControlIntoView(validationLabel);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            base.OnLayout(e);
            ArrangeContent();
        }

        protected override void OnDpiChangedAfterParent(EventArgs e)
        {
            base.OnDpiChangedAfterParent(e);
            ArrangeContent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                RequestCancel();
                return true;
            }
            if (keyData == Keys.Enter)
            {
                // Honor the focused native button while treating Enter in the
                // address field as the default Save and connect action.
                if (cancelButton.Focused) RequestCancel();
                else if (resetButton.Focused) ResetToDefault();
                else RequestSave();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private int Px(int logicalPixels)
        {
            return Math.Max(1, (int)Math.Round(logicalPixels * DeviceDpi / 96F));
        }

        private void ArrangeContent()
        {
            if (!layoutReady || arranging || IsDisposed) return;
            arranging = true;
            try
            {
                int gap = Px(16);
                // Reserve scrollbar space consistently so adding a long error
                // cannot make the content oscillate between two widths.
                int viewportWidth = Math.Max(1, ClientSize.Width - SystemInformation.VerticalScrollBarWidth);
                int width = Math.Max(Px(280), Math.Min(Px(680), viewportWidth - gap * 2));
                bool compact = width < Px(500);
                if (compact != compactActions) ConfigureActionLayout(compact);

                content.Padding = new Padding(Px(24));
                actions.Height = Px(compact ? 132 : 44);
                actions.MinimumSize = new Size(0, actions.Height);
                content.Width = width;
                content.PerformLayout();
                int height = content.GetPreferredSize(new Size(width, 0)).Height;
                content.Height = Math.Max(Px(360), height);

                AutoScrollMinSize = new Size(width + gap * 2, content.Height + gap * 2);
                Point scroll = AutoScrollPosition;
                int x = Math.Max(gap, (viewportWidth - width) / 2);
                content.Location = new Point(x + scroll.X, gap + scroll.Y);
            }
            finally
            {
                arranging = false;
            }
        }

        private void ConfigureActionLayout(bool compact)
        {
            compactActions = compact;
            actions.SuspendLayout();
            actions.Controls.Clear();
            actions.ColumnStyles.Clear();
            actions.RowStyles.Clear();
            actions.ColumnCount = compact ? 1 : 3;
            actions.RowCount = compact ? 3 : 1;
            for (int column = 0; column < actions.ColumnCount; column++)
                actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / actions.ColumnCount));
            for (int row = 0; row < actions.RowCount; row++)
                actions.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / actions.RowCount));
            Button[] buttons = { resetButton, cancelButton, saveButton };
            for (int index = 0; index < buttons.Length; index++)
            {
                buttons[index].Margin = compact
                    ? new Padding(0, 0, 0, Px(6))
                    : new Padding(index == 0 ? 0 : Px(8), 0, 0, 0);
                actions.Controls.Add(buttons[index], compact ? 0 : index, compact ? index : 0);
            }
            actions.ResumeLayout(true);
        }

        private static Label MakeLabel(string text, Color color, Padding margin)
        {
            return new Label
            {
                Text = text,
                AutoSize = true,
                Dock = DockStyle.Fill,
                ForeColor = color,
                Margin = margin,
                UseMnemonic = false,
                TabStop = false
            };
        }

        private static Button MakeButton(string text, Color accent)
        {
            var button = new Button
            {
                Text = text,
                Dock = DockStyle.Fill,
                BackColor = SurfaceColor,
                ForeColor = accent,
                FlatStyle = FlatStyle.Flat,
                UseVisualStyleBackColor = false,
                UseMnemonic = true,
                AutoSize = false,
                TabStop = true
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(79, 85, 75);
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(43, 53, 52);
            button.FlatAppearance.MouseDownBackColor = Color.FromArgb(56, 65, 58);
            return button;
        }

        private void ResetToDefault()
        {
            originInput.Text = NavigationPolicy.DefaultServerOrigin;
            validationLabel.Text = string.Empty;
            FocusServerInput();
        }

        private void RequestCancel()
        {
            EventHandler handler = CancelRequested;
            if (handler != null) handler(this, EventArgs.Empty);
        }

        private void RequestSave()
        {
            string normalized;
            string error;
            if (!NavigationPolicy.TryNormalizeServerOrigin(originInput.Text, out normalized, out error))
            {
                originInput.Focus();
                ShowSaveError(error);
                return;
            }

            Action<string> handler = SaveRequested;
            if (handler == null)
            {
                ShowSaveError("Server settings are not ready. Close these options, reopen them and try again.");
                return;
            }

            // Even the current origin is an explicit save/connect request. The
            // owner decides when persistence succeeds and when to hide options.
            validationLabel.Text = string.Empty;
            handler(normalized);
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing && !resourcesDisposed)
            {
                resourcesDisposed = true;
                headingFont.Dispose();
                kickerFont.Dispose();
            }
        }
    }
}
