using System;
using System.IO;
using Microsoft.Win32;

namespace MetalSlugWarzone.Client.Settings
{
    /// <summary>
    /// Stores the selected server independently of window-placement files.
    /// Uses the current Windows user's registry; never modifies game profiles.
    /// </summary>
    internal static class ServerPreferenceStore
    {
        private const string SubKey = @"Software\Akuma\MetalSlugWarzone\Client";
        private const string ValueName = "ServerOrigin";

        internal static bool TryLoad(out string origin)
        {
            origin = null;
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(SubKey, false))
                {
                    if (key == null) return false;
                    object stored = key.GetValue(ValueName, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                    if (!(stored is string) || key.GetValueKind(ValueName) != RegistryValueKind.String)
                        return false;

                    string error;
                    return NavigationPolicy.TryNormalizeServerOrigin((string)stored, out origin, out error);
                }
            }
            catch (Exception error)
            {
                ClientLog.Write("server-preference-read", error);
                origin = null;
                return false;
            }
        }

        internal static void Save(string normalizedOrigin)
        {
            string canonical;
            string error;
            if (!NavigationPolicy.TryNormalizeServerOrigin(normalizedOrigin, out canonical, out error))
                throw new ArgumentException(error ?? "Enter a valid server domain or IP address.", nameof(normalizedOrigin));

            string stage = "open";
            try
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(SubKey, true))
                {
                    if (key == null)
                        throw new IOException("Windows could not open the server preference for writing.");
                    stage = "write";
                    key.SetValue(ValueName, canonical, RegistryValueKind.String);
                    stage = "flush";
                    key.Flush();
                }

                // Reopen after disposing the write handle. Success requires the
                // exact canonical REG_SZ value to be visible through a fresh read.
                stage = "verify";
                using (RegistryKey check = Registry.CurrentUser.OpenSubKey(SubKey, false))
                {
                    if (check == null ||
                        check.GetValueKind(ValueName) != RegistryValueKind.String ||
                        !string.Equals(check.GetValue(ValueName, null,
                            RegistryValueOptions.DoNotExpandEnvironmentNames) as string,
                            canonical, StringComparison.Ordinal))
                        throw new IOException("Windows did not retain the server preference. Try saving again.");
                }
            }
            catch (Exception registryError)
            {
                ClientLog.Write("server-preference-" + stage, registryError);
                throw;
            }
        }
    }
}
