using System;
using System.Drawing;
using System.Windows.Forms;

namespace MetalSlugWarzone.Client.Settings
{
    public sealed partial class ClientSettings
    {
        internal void ApplyWindow(Form form)
        {
            Rectangle preferred = HasWindowPlacement ? new Rectangle(Left, Top, Width, Height) : form.Bounds;
            Screen screen = HasWindowPlacement ? Screen.FromRectangle(preferred) : Screen.PrimaryScreen;
            Rectangle area = screen.WorkingArea;
            int width = Math.Min(Math.Max(preferred.Width, form.MinimumSize.Width), area.Width);
            int height = Math.Min(Math.Max(preferred.Height, form.MinimumSize.Height), area.Height);
            if (area.Width < form.MinimumSize.Width || area.Height < form.MinimumSize.Height)
                form.MinimumSize = new Size(Math.Min(form.MinimumSize.Width, area.Width), Math.Min(form.MinimumSize.Height, area.Height));
            int x = HasWindowPlacement ? Math.Max(area.Left, Math.Min(preferred.Left, area.Right - width)) : area.Left + (area.Width - width) / 2;
            int y = HasWindowPlacement ? Math.Max(area.Top, Math.Min(preferred.Top, area.Bottom - height)) : area.Top + (area.Height - height) / 2;
            form.StartPosition = FormStartPosition.Manual;
            form.Bounds = new Rectangle(x, y, width, height);
            if (Maximized) form.WindowState = FormWindowState.Maximized;
        }

        internal void CaptureWindow(Form form)
        {
            Rectangle bounds = form.WindowState == FormWindowState.Normal ? form.Bounds : form.RestoreBounds;
            if (bounds.Width < 320 || bounds.Height < 240) return;
            Left = bounds.Left; Top = bounds.Top; Width = bounds.Width; Height = bounds.Height;
            if (form.WindowState != FormWindowState.Minimized) Maximized = form.WindowState == FormWindowState.Maximized;
            HasWindowPlacement = true;
        }
    }
}
