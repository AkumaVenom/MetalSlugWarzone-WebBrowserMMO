using System;
using System.IO;
using System.Globalization;
using System.Text;
using System.Xml;

namespace MetalSlugWarzone.Client.Settings
{
    public sealed partial class ClientSettings
    {
        public string ServerOrigin { get; set; } = NavigationPolicy.DefaultServerOrigin;
        public bool HasWindowPlacement { get; set; }
        public int Left { get; set; }
        public int Top { get; set; }
        public int Width { get; set; } = 1360;
        public int Height { get; set; } = 900;
        public bool Maximized { get; set; }

        internal static ClientSettings Load()
        {
            // Old installations keep their selection until the first successful
            // save. The Windows preference then takes precedence over the XML.
            ClientSettings settings = Load(ClientPaths.SettingsFile);
            string savedOrigin;
            if (ServerPreferenceStore.TryLoad(out savedOrigin))
                settings.ServerOrigin = savedOrigin;
            return settings;
        }

        internal static ClientSettings Load(string settingsFile)
        {
            try
            {
                if (!File.Exists(settingsFile)) return new ClientSettings();
                using (var reader = XmlReader.Create(settingsFile, new XmlReaderSettings
                {
                    DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 16384
                }))
                {
                    // Explicit primitive fields avoid XmlSerializer's runtime
                    // code generation on .NET Framework. Accept the original schema.
                    var document = new XmlDocument { XmlResolver = null };
                    document.Load(reader);
                    XmlElement root = document.DocumentElement;
                    if (root == null || root.Name != "ClientSettings")
                        throw new XmlException("Unexpected client settings root.");
                    var settings = new ClientSettings
                    {
                        ServerOrigin = ReadText(root, "ServerOrigin", NavigationPolicy.DefaultServerOrigin),
                        HasWindowPlacement = ReadBool(root, "HasWindowPlacement", false),
                        Left = ReadInt(root, "Left", 0), Top = ReadInt(root, "Top", 0),
                        Width = ReadInt(root, "Width", 1360), Height = ReadInt(root, "Height", 900),
                        Maximized = ReadBool(root, "Maximized", false)
                    };
                    string origin, error;
                    if (!NavigationPolicy.TryNormalizeServerOrigin(settings.ServerOrigin, out origin, out error))
                        settings.ServerOrigin = NavigationPolicy.DefaultServerOrigin;
                    else settings.ServerOrigin = origin;
                    if (settings.Width < 320 || settings.Width > 16384 || settings.Height < 240 || settings.Height > 16384)
                        settings.HasWindowPlacement = false;
                    return settings;
                }
            }
            catch (Exception error)
            {
                ClientLog.Write("settings-read", error);
                return new ClientSettings();
            }
        }

        internal void Save()
        {
            Save(ClientPaths.SettingsFile);
        }

        internal void Save(string settingsFile)
        {
            settingsFile = Path.GetFullPath(settingsFile);
            Directory.CreateDirectory(Path.GetDirectoryName(settingsFile));
            string temp = settingsFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    using (var writer = XmlWriter.Create(stream, new XmlWriterSettings
                    {
                        Encoding = new UTF8Encoding(false), Indent = true, CloseOutput = false
                    }))
                    {
                        writer.WriteStartElement("ClientSettings");
                        writer.WriteElementString("ServerOrigin", ServerOrigin);
                        writer.WriteElementString("HasWindowPlacement", XmlConvert.ToString(HasWindowPlacement));
                        writer.WriteElementString("Left", XmlConvert.ToString(Left));
                        writer.WriteElementString("Top", XmlConvert.ToString(Top));
                        writer.WriteElementString("Width", XmlConvert.ToString(Width));
                        writer.WriteElementString("Height", XmlConvert.ToString(Height));
                        writer.WriteElementString("Maximized", XmlConvert.ToString(Maximized));
                        writer.WriteEndElement();
                    }
                    stream.Flush(true);
                }
                if (File.Exists(settingsFile)) File.Replace(temp, settingsFile, null);
                else File.Move(temp, settingsFile);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }

        internal bool TrySaveServerOrigin(string input, out string error)
        {
            string normalized;
            if (!NavigationPolicy.TryNormalizeServerOrigin(input, out normalized, out error))
                return false;

            try
            {
                // This is the authoritative save. It includes a fresh readback;
                // window placement and XML errors must not block a server change.
                ServerPreferenceStore.Save(normalized);
            }
            catch (Exception saveError)
            {
                ClientLog.Write("server-preference-save", saveError);
                error = "Windows could not save the server preference (" + ClientLog.ErrorCode(saveError) +
                    "). Your previous selection is still active. Please share this error code if it continues.";
                return false;
            }

            ServerOrigin = normalized;
            try { Save(); }
            catch (Exception windowError) { ClientLog.Write("window-settings-save", windowError); }
            error = null;
            return true;
        }

        internal bool TrySaveServerOrigin(string input, string settingsFile, out string error)
        {
            string normalized;
            if (!NavigationPolicy.TryNormalizeServerOrigin(input, out normalized, out error))
                return false;

            string previous = ServerOrigin;
            ServerOrigin = normalized;
            try
            {
                // "Save and connect" must persist even when the selected server
                // is unchanged, including when its settings file was removed.
                Save(settingsFile);
                error = null;
                return true;
            }
            catch (Exception saveError)
            {
                ServerOrigin = previous;
                ClientLog.Write("settings-write", saveError);
                error = "The settings file could not be saved (" + ClientLog.ErrorCode(saveError) + ").";
                return false;
            }
        }

        private static string ReadText(XmlElement root, string name, string fallback)
        {
            XmlElement element = root[name];
            return element == null ? fallback : element.InnerText;
        }

        private static int ReadInt(XmlElement root, string name, int fallback)
        {
            int value;
            return int.TryParse(ReadText(root, name, null), NumberStyles.Integer,
                CultureInfo.InvariantCulture, out value) ? value : fallback;
        }

        private static bool ReadBool(XmlElement root, string name, bool fallback)
        {
            string text = ReadText(root, name, null);
            if (text == "1" || text == "true") return true;
            if (text == "0" || text == "false") return false;
            return fallback;
        }
    }
}
