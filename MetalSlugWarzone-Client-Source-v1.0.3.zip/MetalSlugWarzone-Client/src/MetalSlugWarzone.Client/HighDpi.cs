using System;
using System.Runtime.InteropServices;

namespace MetalSlugWarzone.Client
{
    internal static class HighDpi
    {
        private static readonly IntPtr PerMonitorV2 = new IntPtr(-4);

        internal static void EnableBeforeWindows()
        {
            try
            {
                // Explicitly establish the process default before any UI exists.
                // App.config also enables the .NET Framework control/layout features.
                if (!SetProcessDpiAwarenessContext(PerMonitorV2))
                {
                    int error = Marshal.GetLastWin32Error();
                    // An already-established context cannot be set again. Treat
                    // that as success when it is already the requested mode.
                    if (!AreDpiAwarenessContextsEqual(GetThreadDpiAwarenessContext(), PerMonitorV2))
                        ClientLog.Write("dpi-enable Win32=" + error);
                }
            }
            catch (EntryPointNotFoundException error)
            {
                // The supported Windows 10/11 versions provide these APIs.
                // Keep framework-configured scaling usable on older systems.
                ClientLog.Write("dpi-api-unavailable", error);
            }
        }

        internal static void LogCurrentMode()
        {
            try
            {
                IntPtr context = GetThreadDpiAwarenessContext();
                bool perMonitorV2 = AreDpiAwarenessContextsEqual(context, PerMonitorV2);
                ClientLog.Write(perMonitorV2 ? "dpi-awareness PerMonitorV2" :
                    "dpi-awareness " + GetAwarenessFromDpiAwarenessContext(context));
            }
            catch (EntryPointNotFoundException error)
            {
                ClientLog.Write("dpi-query-unavailable", error);
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr value);

        [DllImport("user32.dll")]
        private static extern IntPtr GetThreadDpiAwarenessContext();

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool AreDpiAwarenessContextsEqual(IntPtr first, IntPtr second);

        [DllImport("user32.dll")]
        private static extern int GetAwarenessFromDpiAwarenessContext(IntPtr value);
    }
}
