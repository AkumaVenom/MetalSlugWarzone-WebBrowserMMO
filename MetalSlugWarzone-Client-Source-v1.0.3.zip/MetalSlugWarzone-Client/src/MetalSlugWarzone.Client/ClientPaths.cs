using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace MetalSlugWarzone.Client
{
    internal static class ClientPaths
    {
        internal static readonly string Root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MetalSlugWarzone", "Client");
        internal static readonly string SettingsFile = Path.Combine(Root, "client-settings.xml");
        internal static readonly string LogFile = Path.Combine(Root, "client.log");

        internal static string ProfileFor(string origin)
        {
            using (var hash = SHA256.Create())
            {
                string key = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(origin))).Replace("-", "").ToLowerInvariant();
                return Path.Combine(Root, "Profiles", key.Substring(0, 32));
            }
        }
    }

    internal static class ClientLog
    {
        private static readonly object Gate = new object();
        internal static void Write(string operation, Exception error)
        {
            // Record type and HRESULT, never page URLs, query strings, cookies or credentials.
            var details = new StringBuilder(operation);
            for (Exception current = error; current != null; current = current.InnerException)
                details.Append(": ").Append(current.GetType().Name).Append(" (0x")
                    .Append(current.HResult.ToString("X8")).Append(")");
            Write(details.ToString());
        }

        internal static string ErrorCode(Exception error)
        {
            while (error.InnerException != null) error = error.InnerException;
            return error.GetType().Name + ", 0x" + error.HResult.ToString("X8");
        }

        internal static void Write(string message)
        {
            try
            {
                lock (Gate)
                {
                    Directory.CreateDirectory(ClientPaths.Root);
                    if (File.Exists(ClientPaths.LogFile) && new FileInfo(ClientPaths.LogFile).Length > 256 * 1024)
                        File.Delete(ClientPaths.LogFile);
                    File.AppendAllText(ClientPaths.LogFile, DateTime.UtcNow.ToString("O") + " " + message + Environment.NewLine);
                }
            }
            catch { /* A read-only log folder must not interrupt a game. */ }
        }
    }
}
