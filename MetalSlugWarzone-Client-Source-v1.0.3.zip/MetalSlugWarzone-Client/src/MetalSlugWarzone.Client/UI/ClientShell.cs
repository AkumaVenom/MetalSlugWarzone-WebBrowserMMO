using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace MetalSlugWarzone.Client.UI
{
    /// <summary>Native window chrome only; all game and browser behavior belongs to the host.</summary>
    public class ClientShell : Form
    {
        // Keep native sizing/taskbar behavior, but never give Windows a caption to paint.
        private const int NativeCaptionStyles = 0x00C00000; // WS_CAPTION includes WS_BORDER and WS_DLGFRAME.
        private const int NativeWindowControls = 0x00040000 | 0x00020000 | 0x00010000 | 0x00080000;
        private const int NativeEdgeStyles = 0x00000001 | 0x00000100 | 0x00000200 | 0x00020000;
        private static readonly Color Charcoal = Color.FromArgb(17, 21, 25);
        private static readonly Color Surface = Color.FromArgb(25, 30, 34);
        private static readonly Color Gold = Color.FromArgb(232, 182, 74);
        private static readonly Color Cyan = Color.FromArgb(113, 211, 219);
        private static readonly Color Muted = Color.FromArgb(155, 168, 177);
        private readonly List<Font> _fonts = new List<Font>();
        private readonly ToolTip _tips = new ToolTip { InitialDelay = 450, ReshowDelay = 100 };
        private readonly Panel _title = new Panel(), _content = new Panel(), _footer = new Panel();
        private readonly Label _brand = new Label(), _subtitle = new Label(), _status = new Label(), _link = new Label();
        private readonly ShellButton _home, _reload, _options, _fullscreen, _minimize, _maximize, _close;
        private readonly Panel _notice = new Panel(), _card = new Panel(), _clientOverlay = new Panel();
        private readonly Label _noticeEyebrow = new Label(), _noticeTitle = new Label(), _noticeMessage = new Label();
        private readonly ShellButton _primary, _secondary;
        private Action _primaryAction, _secondaryAction;
        private Rectangle _windowedBounds;
        private FormWindowState _windowedState;
        private bool _busy, _warning, _layoutReady, _performingLayout, _showingNotice, _disposed;
        private int _nextTabIndex;

        public Panel BrowserHost { get; private set; }
        public bool IsFullscreen { get; private set; }
        public bool IsClientOverlayVisible { get; private set; }
        public event EventHandler HomeRequested;
        public event EventHandler ReloadRequested;
        public event EventHandler OptionsRequested;
        public event EventHandler FullscreenChanged;

        public ClientShell()
        {
            AutoScaleDimensions = new SizeF(96, 96);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = OwnFont(9.5f);
            Text = "Metal Slug Warzone";
            BackColor = Charcoal;
            ForeColor = Color.WhiteSmoke;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1280, 820);
            KeyPreview = true;
            DoubleBuffered = true;

            _title.BackColor = Surface;
            _footer.BackColor = Surface;
            _title.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (var pen = new Pen(Gold)) e.Graphics.DrawLine(pen, 0, _title.Height - 1, _title.Width, _title.Height - 1);
            };
            ConfigureLabel(_brand, "METAL SLUG  /  WARZONE", OwnFont(12f, FontStyle.Bold), Gold);
            ConfigureLabel(_subtitle, "TACTICAL OPERATIONS NETWORK", OwnFont(7.5f, FontStyle.Bold), Muted);
            ConfigureLabel(_status, "Preparing your battlefield...", Font, Muted);
            ConfigureLabel(_link, "CONNECTING...", OwnFont(7.5f, FontStyle.Bold), Gold);
            _status.AutoEllipsis = true;
            _link.TextAlign = ContentAlignment.MiddleRight;
            _title.MouseDown += DragTitle;
            _brand.MouseDown += DragTitle;
            _subtitle.MouseDown += DragTitle;

            _home = MakeButton("HOME", "Return to the game home page (Alt+Home)", delegate { HomeRequested?.Invoke(this, EventArgs.Empty); });
            _reload = MakeButton("RECONNECT", "Reload the current game page (Ctrl+R)", delegate { ReloadRequested?.Invoke(this, EventArgs.Empty); });
            _options = MakeButton("OPTIONS", "Client options and server address", delegate { OptionsRequested?.Invoke(this, EventArgs.Empty); });
            _fullscreen = MakeButton("FULLSCREEN", "Enter or leave fullscreen (F11)", ToggleFullscreen);
            _minimize = MakeButton("", "Minimize", delegate { WindowState = FormWindowState.Minimized; }, CaptionGlyph.Minimize);
            _maximize = MakeButton("", "Maximize or restore", ToggleMaximize, CaptionGlyph.Maximize);
            _close = MakeButton("", "Close Metal Slug Warzone", Close, CaptionGlyph.Close);
            _close.IsClose = true;
            _title.Controls.AddRange(new Control[] { _brand, _subtitle, _home, _reload, _options, _fullscreen, _minimize, _maximize, _close });
            _footer.Controls.AddRange(new Control[] { _status, _link });

            BrowserHost = new Panel { BackColor = Color.FromArgb(12, 15, 18), Dock = DockStyle.Fill, TabIndex = 1 };
            _content.Controls.Add(BrowserHost);
            _notice.BackColor = Charcoal;
            _notice.Dock = DockStyle.Fill;
            _notice.AutoScroll = true;
            _notice.Visible = false;
            _card.BackColor = Surface;
            _card.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (var brush = new SolidBrush(Gold)) e.Graphics.FillRectangle(brush, 0, 0, _card.Width, Px(3));
            };
            ConfigureLabel(_noticeEyebrow, "WARZONE  /  COMMAND TERMINAL", OwnFont(8f, FontStyle.Bold), Gold);
            ConfigureLabel(_noticeTitle, "", OwnFont(22f, FontStyle.Bold), Color.WhiteSmoke);
            ConfigureLabel(_noticeMessage, "", OwnFont(10.5f), Muted);
            _primary = MakeButton("", "Continue", delegate { _primaryAction?.Invoke(); });
            _primary.Accent = true;
            _secondary = MakeButton("", "Cancel", delegate { _secondaryAction?.Invoke(); });
            _card.Controls.AddRange(new Control[] { _noticeEyebrow, _noticeTitle, _noticeMessage, _primary, _secondary });
            _notice.Controls.Add(_card);
            _content.Controls.Add(_notice);
            _clientOverlay.BackColor = Charcoal;
            _clientOverlay.Dock = DockStyle.Fill;
            _clientOverlay.Visible = false;
            _content.Controls.Add(_clientOverlay);
            _content.TabIndex = 1;
            _title.TabIndex = 0;
            _footer.TabStop = false;
            Controls.AddRange(new Control[] { _content, _title, _footer });
            _layoutReady = true;
            SetBusy(true);
            ApplyWindowLayout();
        }

        private Font OwnFont(float size, FontStyle style = FontStyle.Regular)
        {
            var font = new Font("Segoe UI", size, style, GraphicsUnit.Point);
            _fonts.Add(font);
            return font;
        }

        private static void ConfigureLabel(Label label, string text, Font font, Color color)
        {
            label.Text = text;
            label.Font = font;
            label.ForeColor = color;
            label.BackColor = Color.Transparent;
            label.UseMnemonic = false;
            label.TextAlign = ContentAlignment.MiddleLeft;
        }

        private ShellButton MakeButton(string text, string description, Action action, CaptionGlyph glyph = CaptionGlyph.None)
        {
            var button = new ShellButton { Text = text, Font = Font, AccessibleName = description, Glyph = glyph, TabIndex = _nextTabIndex++ };
            button.Click += delegate { action(); };
            _tips.SetToolTip(button, description);
            return button;
        }

        public void SetStatus(string text, bool warning = false)
        {
            _status.Text = text ?? "";
            _tips.SetToolTip(_status, _status.Text);
            _warning = warning;
            _status.ForeColor = warning ? Gold : Muted;
            UpdateLinkState();
        }

        public void SetBusy(bool busy)
        {
            _busy = busy;
            UpdateInteractionState();
            UpdateLinkState();
        }

        private void UpdateInteractionState()
        {
            BrowserHost.Enabled = !_showingNotice && !IsClientOverlayVisible;
            _notice.Enabled = !IsClientOverlayVisible;
            _home.Enabled = _options.Enabled = !IsClientOverlayVisible;
            _reload.Enabled = !_busy && !IsClientOverlayVisible;
        }

        private void UpdateLinkState()
        {
            _link.Text = _warning ? "ATTENTION" : _busy ? "CONNECTING..." : "COMMAND LINK";
            _link.ForeColor = _warning || _busy ? Gold : Cyan;
        }

        public void ShowNotice(string title, string message, string primaryText, Action primaryAction, string secondaryText = null, Action secondaryAction = null)
        {
            _noticeTitle.Text = title ?? "";
            _noticeMessage.Text = message ?? "";
            _primary.Text = primaryText ?? "";
            _secondary.Text = secondaryText ?? "";
            _primary.AccessibleName = _primary.Text;
            _secondary.AccessibleName = _secondary.Text;
            _tips.SetToolTip(_primary, _primary.Text);
            _tips.SetToolTip(_secondary, _secondary.Text);
            _primaryAction = primaryAction;
            _secondaryAction = secondaryAction;
            _primary.Visible = !string.IsNullOrEmpty(primaryText) && primaryAction != null;
            _secondary.Visible = !string.IsNullOrEmpty(secondaryText) && secondaryAction != null;
            _showingNotice = true;
            UpdateInteractionState();
            _notice.Visible = true;
            LayoutNotice();
            if (!IsClientOverlayVisible)
            {
                _notice.BringToFront(); // A native sibling panel also covers the WebView2 child HWND.
                AcceptButton = _primary.Visible ? _primary : null;
                if (_primary.Visible) _primary.Select();
            }
            else _clientOverlay.BringToFront();
        }

        public void HideNotice()
        {
            AcceptButton = null;
            _showingNotice = false;
            _notice.Visible = false;
            UpdateInteractionState();
            _primaryAction = null;
            _secondaryAction = null;
            if (!IsClientOverlayVisible) BrowserHost.SelectNextControl(null, true, true, true, false);
        }

        /// <summary>Displays client settings above the game/notice without changing their state.</summary>
        public void ShowClientOverlay(Control content)
        {
            if (content == null) throw new ArgumentNullException(nameof(content));
            if (content.IsDisposed) throw new ObjectDisposedException(nameof(content));
            AcceptButton = null;
            IsClientOverlayVisible = true;
            UpdateInteractionState();
            _clientOverlay.SuspendLayout();
            try
            {
                // Removing a control leaves its lifetime with the caller.
                _clientOverlay.Controls.Clear();
                content.Dock = DockStyle.Fill;
                _clientOverlay.Controls.Add(content);
            }
            finally { _clientOverlay.ResumeLayout(true); }
            _clientOverlay.Visible = true;
            _clientOverlay.BringToFront();
            if (!content.SelectNextControl(null, true, true, true, false)) content.Select();
        }

        /// <summary>Removes, but does not dispose, the caller-owned overlay content.</summary>
        public void HideClientOverlay()
        {
            if (!IsClientOverlayVisible) return;
            _clientOverlay.Visible = false;
            _clientOverlay.Controls.Clear();
            IsClientOverlayVisible = false;
            UpdateInteractionState();
            AcceptButton = _showingNotice && _primary.Visible ? _primary : null;
            if (_showingNotice)
            {
                _notice.BringToFront();
                if (_primary.Visible) _primary.Select();
                else _home.Select();
            }
            else BrowserHost.SelectNextControl(null, true, true, true, false);
        }

        public void ToggleFullscreen()
        {
            if (IsFullscreen) { ExitFullscreen(); return; }
            _windowedState = WindowState == FormWindowState.Minimized ? FormWindowState.Normal : WindowState;
            _windowedBounds = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            var screen = Screen.FromHandle(Handle);
            IsFullscreen = true;
            WindowState = FormWindowState.Normal;
            MinimumSize = Size.Empty;
            ApplyWindowLayout();
            Bounds = screen.Bounds;
            FullscreenChanged?.Invoke(this, EventArgs.Empty);
        }

        public void ExitFullscreen()
        {
            if (!IsFullscreen) return;
            IsFullscreen = false;
            WindowState = FormWindowState.Normal;
            Bounds = VisibleBounds(_windowedBounds);
            UpdateMinimumSize();
            ApplyWindowLayout();
            WindowState = _windowedState;
            FullscreenChanged?.Invoke(this, EventArgs.Empty);
        }

        private void ToggleMaximize()
        {
            if (IsFullscreen) ExitFullscreen();
            WindowState = WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        }

        private void DragTitle(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || IsFullscreen) return;
            if (e.Clicks == 2) { ToggleMaximize(); return; }
            ReleaseCapture();
            SendMessage(Handle, 0x00A1, new IntPtr(2), IntPtr.Zero);
        }

        // WebView2 forwards browser accelerators as KeyDown. Command-key processing
        // also posts work so browser navigation/resize cannot block that callback.
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (IsClientOverlayVisible) return base.ProcessCmdKey(ref msg, keyData);
            Action action = null;
            if (keyData == Keys.F11)
            {
                // WM_KEYDOWN bit 30 identifies auto-repeat while native controls have focus.
                if ((msg.LParam.ToInt64() & 0x40000000L) != 0) return true;
                action = ToggleFullscreen;
            }
            else if (keyData == Keys.Escape && IsFullscreen) action = ExitFullscreen;
            else if (keyData == (Keys.Alt | Keys.Home)) action = delegate { HomeRequested?.Invoke(this, EventArgs.Empty); };
            else if (keyData == (Keys.Control | Keys.R)) action = delegate { ReloadRequested?.Invoke(this, EventArgs.Empty); };
            if (action != null) { QueueKeyboardCommand(action); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void QueueKeyboardCommand(Action action)
        {
            if (IsDisposed || Disposing || !IsHandleCreated) return;
            try
            {
                BeginInvoke(new Action(delegate { if (!IsDisposed && !Disposing) action(); }));
            }
            catch (InvalidOperationException) when (IsDisposed || Disposing || !IsHandleCreated)
            {
                // The window was destroyed before Windows could accept the queued command.
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            UpdateMinimumSize();
            if (WindowState == FormWindowState.Normal) Bounds = VisibleBounds(Bounds);
            base.OnLoad(e);
        }

        protected override void OnDpiChanged(DpiChangedEventArgs e)
        {
            base.OnDpiChanged(e);
            if (!IsFullscreen) UpdateMinimumSize();
            else Bounds = Screen.FromHandle(Handle).Bounds;
            ApplyWindowLayout();
        }

        protected override void OnLayout(LayoutEventArgs levent)
        {
            base.OnLayout(levent);
            if (_layoutReady) ApplyWindowLayout();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (_maximize != null)
            {
                _maximize.Glyph = WindowState == FormWindowState.Maximized ? CaptionGlyph.Restore : CaptionGlyph.Maximize;
                _maximize.Invalidate();
            }
        }

        private int Px(int value) { return (int)Math.Round(value * DeviceDpi / 96.0); }

        private void ApplyWindowLayout()
        {
            if (!_layoutReady || _performingLayout) return;
            _performingLayout = true;
            try
            {
                int rim = IsFullscreen ? 0 : WindowState == FormWindowState.Maximized ? Px(1) : Px(6);
                int width = Math.Max(0, ClientSize.Width - rim * 2);
                int top = IsFullscreen ? 0 : Px(64), bottom = IsFullscreen ? 0 : Px(28);
                _title.Visible = _footer.Visible = !IsFullscreen;
                _title.SetBounds(rim, rim, width, top);
                _footer.SetBounds(rim, Math.Max(rim, ClientSize.Height - rim - bottom), width, bottom);
                _content.SetBounds(rim, rim + top, width, Math.Max(0, ClientSize.Height - rim * 2 - top - bottom));
                int right = width - Px(8), captionWidth = Px(42), buttonY = Px(12), buttonHeight = Px(38);
                foreach (var button in new[] { _close, _maximize, _minimize })
                {
                    right -= captionWidth;
                    button.SetBounds(right, buttonY, captionWidth, buttonHeight);
                }
                right -= Px(10);
                PlaceButton(_fullscreen, ref right, 104, buttonY, buttonHeight);
                PlaceButton(_options, ref right, 84, buttonY, buttonHeight);
                PlaceButton(_reload, ref right, 104, buttonY, buttonHeight);
                PlaceButton(_home, ref right, 68, buttonY, buttonHeight);
                int brandWidth = Math.Max(0, right - Px(28));
                _brand.SetBounds(Px(16), Px(11), brandWidth, Px(24));
                _subtitle.SetBounds(Px(17), Px(36), brandWidth, Px(16));
                _brand.AutoEllipsis = _subtitle.AutoEllipsis = true;
                _link.SetBounds(Math.Max(Px(16), width - Px(166)), 0, Px(150), bottom);
                _status.SetBounds(Px(16), 0, Math.Max(0, width - Px(198)), bottom);
                if (_showingNotice) LayoutNotice();
                Invalidate();
            }
            finally { _performingLayout = false; }
        }

        private void PlaceButton(Control button, ref int right, int logicalWidth, int y, int height)
        {
            right -= Px(logicalWidth);
            button.SetBounds(right, y, Px(logicalWidth), height);
            right -= Px(5);
        }

        private void LayoutNotice()
        {
            int width = Math.Max(Px(200), Math.Min(Px(650), _content.ClientSize.Width - Px(48)));
            int pad = Px(30), textWidth = Math.Max(Px(100), width - pad * 2);
            int y = Px(26);
            _noticeEyebrow.SetBounds(pad, y, textWidth, Px(20));
            y += Px(38);
            int titleHeight = MeasureHeight(_noticeTitle, textWidth);
            _noticeTitle.SetBounds(pad, y, textWidth, titleHeight);
            y += titleHeight + Px(16);
            int messageHeight = MeasureHeight(_noticeMessage, textWidth);
            _noticeMessage.SetBounds(pad, y, textWidth, messageHeight);
            y += messageHeight + Px(27);
            int x = pad;
            foreach (var button in new[] { _primary, _secondary })
            {
                if (!button.Visible) continue;
                int buttonWidth = Math.Min(textWidth, Math.Max(Px(140), TextRenderer.MeasureText(button.Text, Font).Width + Px(34)));
                if (x + buttonWidth > width - pad) { x = pad; y += Px(50); }
                button.SetBounds(x, y, buttonWidth, Px(40));
                x += buttonWidth + Px(10);
            }
            if (_primary.Visible || _secondary.Visible) y += Px(40);
            int height = y + Px(28);
            _card.SetBounds(Math.Max(Px(16), (_content.ClientSize.Width - width) / 2), Math.Max(Px(24), (_content.ClientSize.Height - height) / 2), width, height);
            _notice.AutoScrollMinSize = new Size(0, _card.Bottom + Px(24));
        }

        private static int MeasureHeight(Label label, int width)
        {
            return TextRenderer.MeasureText(label.Text.Length == 0 ? " " : label.Text, label.Font,
                new Size(width, int.MaxValue), TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix).Height + 4;
        }

        private void UpdateMinimumSize()
        {
            var work = Screen.FromHandle(Handle).WorkingArea;
            MinimumSize = new Size(Math.Min(Px(900), work.Width), Math.Min(Px(600), work.Height));
        }

        private static Rectangle VisibleBounds(Rectangle requested)
        {
            var work = Screen.FromRectangle(requested).WorkingArea;
            int width = Math.Min(requested.Width, work.Width), height = Math.Min(requested.Height, work.Height);
            return new Rectangle(Math.Max(work.Left, Math.Min(requested.Left, work.Right - width)),
                Math.Max(work.Top, Math.Min(requested.Top, work.Bottom - height)), width, height);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var value = base.CreateParams;
                value.Style = (value.Style & ~NativeCaptionStyles) | NativeWindowControls;
                value.ExStyle &= ~NativeEdgeStyles;
                return value;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x007C && m.LParam != IntPtr.Zero) // WM_STYLECHANGING
            {
                // WinForms can update styles when a modal owner is disabled or a handle
                // is recreated. Apply the same borderless policy to those later changes.
                var styles = (NativeStyleChange)Marshal.PtrToStructure(m.LParam, typeof(NativeStyleChange));
                if (m.WParam == new IntPtr(-16)) // GWL_STYLE
                    styles.NewStyle = (styles.NewStyle & ~NativeCaptionStyles) | NativeWindowControls;
                else if (m.WParam == new IntPtr(-20)) // GWL_EXSTYLE
                    styles.NewStyle &= ~NativeEdgeStyles;
                Marshal.StructureToPtr(styles, m.LParam, false);
                m.Result = IntPtr.Zero;
                return;
            }
            if (m.Msg == 0x0083) // WM_NCCALCSIZE: both RECT and NCCALCSIZE_PARAMS forms.
            {
                // Leave the proposed outer rectangle untouched: the whole window is
                // client area, including initial creation and later frame recalculation.
                m.Result = IntPtr.Zero;
                return;
            }
            if (m.Msg == 0x0085) // WM_NCPAINT: the shell paints its entire frame as client controls.
            {
                m.Result = IntPtr.Zero;
                return;
            }
            if (m.Msg == 0x0086) // WM_NCACTIVATE
            {
                // -1 is the documented way to update activation without repainting a
                // native caption. Keep normal processing for taskbar/minimized windows.
                if (WindowState != FormWindowState.Minimized) m.LParam = new IntPtr(-1);
                base.WndProc(ref m);
                return;
            }
            if (m.Msg == 0x0024)
            {
                var info = (MinMaxInfo)Marshal.PtrToStructure(m.LParam, typeof(MinMaxInfo));
                var monitor = new MonitorInfo { Size = Marshal.SizeOf(typeof(MonitorInfo)) };
                if (GetMonitorInfo(MonitorFromWindow(Handle, 2), ref monitor))
                {
                    var target = IsFullscreen ? monitor.Monitor : monitor.Work;
                    info.MaxPosition = new NativePoint(target.Left - monitor.Monitor.Left, target.Top - monitor.Monitor.Top);
                    info.MaxSize = new NativePoint(target.Right - target.Left, target.Bottom - target.Top);
                    info.MinTrackSize = IsFullscreen ? new NativePoint(0, 0) : new NativePoint(
                        Math.Min(Px(900), monitor.Work.Right - monitor.Work.Left), Math.Min(Px(600), monitor.Work.Bottom - monitor.Work.Top));
                    Marshal.StructureToPtr(info, m.LParam, false);
                }
                m.Result = IntPtr.Zero;
                return;
            }
            base.WndProc(ref m);
            if (m.Msg != 0x0084 || IsFullscreen || WindowState != FormWindowState.Normal) return;
            long location = m.LParam.ToInt64();
            var point = PointToClient(new Point(unchecked((short)(location & 0xffff)), unchecked((short)((location >> 16) & 0xffff))));
            int edge = Px(6);
            bool left = point.X < edge, right = point.X >= ClientSize.Width - edge;
            bool top = point.Y < edge, bottom = point.Y >= ClientSize.Height - edge;
            int hit = top ? (left ? 13 : right ? 14 : 12) : bottom ? (left ? 16 : right ? 17 : 15) : left ? 10 : right ? 11 : 1;
            m.Result = new IntPtr(hit);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && !_disposed) _tips.Dispose();
            base.Dispose(disposing);
            if (disposing && !_disposed)
            {
                foreach (var font in _fonts) font.Dispose();
                _disposed = true;
            }
        }

        [StructLayout(LayoutKind.Sequential)] private struct NativePoint { public int X, Y; public NativePoint(int x, int y) { X = x; Y = y; } }
        [StructLayout(LayoutKind.Sequential)] private struct NativeRect { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] private struct NativeStyleChange { public int OldStyle, NewStyle; }
        [StructLayout(LayoutKind.Sequential)] private struct MinMaxInfo { public NativePoint Reserved, MaxSize, MaxPosition, MinTrackSize, MaxTrackSize; }
        [StructLayout(LayoutKind.Sequential)] private struct MonitorInfo { public int Size; public NativeRect Monitor, Work; public uint Flags; }
        [DllImport("user32.dll")] private static extern bool ReleaseCapture();
        [DllImport("user32.dll")] private static extern IntPtr SendMessage(IntPtr handle, int message, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);
        [DllImport("user32.dll", CharSet = CharSet.Auto)] private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
    }

    internal enum CaptionGlyph { None, Minimize, Maximize, Restore, Close }

    /// <summary>Owner-painted native Button: keyboard and accessibility behavior remain intact.</summary>
    internal sealed class ShellButton : Button
    {
        private bool _hover, _pressed;
        public CaptionGlyph Glyph { get; set; }
        public bool Accent { get; set; }
        public bool IsClose { get; set; }

        public ShellButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            Cursor = Cursors.Hand;
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _pressed = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { _pressed = e.Button == MouseButtons.Left; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _pressed = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var gold = Color.FromArgb(232, 182, 74);
            Color background = Accent ? gold : _pressed ? Color.FromArgb(58, 66, 72) : _hover ? Color.FromArgb(43, 51, 58) : Color.FromArgb(30, 36, 41);
            if (IsClose && _hover) background = Color.FromArgb(174, 56, 51);
            Color foreground = !Enabled ? Color.FromArgb(100, 108, 112) : Accent ? Color.FromArgb(24, 26, 28) : Color.FromArgb(228, 232, 235);
            using (var brush = new SolidBrush(background)) e.Graphics.FillRectangle(brush, ClientRectangle);
            if (Glyph == CaptionGlyph.None)
                TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, foreground, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
            else
            {
                float scale = DeviceDpi / 96f;
                int size = (int)Math.Round(10 * scale), x = (Width - size) / 2, y = (Height - size) / 2;
                using (var pen = new Pen(foreground, Math.Max(1f, scale)))
                {
                    if (Glyph == CaptionGlyph.Minimize) e.Graphics.DrawLine(pen, x, y + size / 2, x + size, y + size / 2);
                    else if (Glyph == CaptionGlyph.Close)
                    {
                        e.Graphics.DrawLine(pen, x, y, x + size, y + size);
                        e.Graphics.DrawLine(pen, x + size, y, x, y + size);
                    }
                    else if (Glyph == CaptionGlyph.Maximize) e.Graphics.DrawRectangle(pen, x, y, size, size);
                    else
                    {
                        int offset = Math.Max(2, (int)Math.Round(3 * scale));
                        e.Graphics.DrawRectangle(pen, x + offset, y, size - offset, size - offset);
                        using (var brush = new SolidBrush(background)) e.Graphics.FillRectangle(brush, x, y + offset, size - offset, size - offset);
                        e.Graphics.DrawRectangle(pen, x, y + offset, size - offset, size - offset);
                    }
                }
            }
            if (Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -4, -4), foreground, background);
        }
    }
}
