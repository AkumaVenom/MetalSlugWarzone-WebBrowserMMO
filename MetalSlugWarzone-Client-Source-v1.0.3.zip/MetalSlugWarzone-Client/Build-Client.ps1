# Run on Windows with Visual Studio 2022's .NET desktop development workload.
$ErrorActionPreference = 'Stop'
try {
    $solution = Join-Path $PSScriptRoot 'MetalSlugWarzone.Client.sln'
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $vswhere)) {
        throw 'Install Visual Studio 2022 with .NET desktop development, then run this build again.'
    }
    $msbuild = & $vswhere -latest -products '*' -requires Microsoft.Component.MSBuild -version '[17.0,18.0)' -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
    if ([string]::IsNullOrWhiteSpace($msbuild)) {
        throw 'Visual Studio 2022 MSBuild was not found. Add the .NET desktop development workload.'
    }
    & $msbuild $solution '-restore' '-t:Rebuild' '-p:Configuration=Release' '-p:Platform=x64' '-p:RestoreLockedMode=true' '-verbosity:minimal' '-nologo'
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed. The compiler messages above explain what needs attention.' }

    $built = Join-Path $PSScriptRoot 'src\MetalSlugWarzone.Client\bin\x64\Release\net48'
    $dist = Join-Path $PSScriptRoot 'dist\MetalSlugWarzone-Client-Windows-x64'
    $files = @('MetalSlugWarzone.Client.exe','MetalSlugWarzone.Client.exe.config','Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.WinForms.dll')
    foreach ($name in $files) {
        if (-not (Test-Path -LiteralPath (Join-Path $built $name))) { throw ('Build output is missing ' + $name) }
    }
    $loader = Join-Path $built 'WebView2Loader.dll'
    if (-not (Test-Path -LiteralPath $loader)) { $loader = Join-Path $built 'runtimes\win-x64\native\WebView2Loader.dll' }
    if (-not (Test-Path -LiteralPath $loader)) { throw 'The x64 WebView2 native loader is missing from the build.' }

    if (Test-Path -LiteralPath $dist) { Remove-Item -LiteralPath $dist -Recurse -Force }
    $null = New-Item -ItemType Directory -Path $dist -Force
    foreach ($name in $files) { Copy-Item -LiteralPath (Join-Path $built $name) -Destination $dist }
    Copy-Item -LiteralPath $loader -Destination (Join-Path $dist 'WebView2Loader.dll')
    Copy-Item -Path (Join-Path $PSScriptRoot 'distribution\*') -Destination $dist -Recurse
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'THIRD_PARTY_NOTICES.txt') -Destination $dist
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'licenses\WebView2-LICENSE.txt') -Destination $dist

    $hashLines = Get-ChildItem -LiteralPath $dist -File | Where-Object Name -ne 'SHA256SUMS.txt' | Sort-Object Name | ForEach-Object {
        ((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + $_.Name)
    }
    $hashLines | Set-Content -LiteralPath (Join-Path $dist 'SHA256SUMS.txt') -Encoding ASCII
    $zip = Join-Path $PSScriptRoot 'dist\MetalSlugWarzone-Client-Windows-x64.zip'
    Compress-Archive -LiteralPath $dist -DestinationPath $zip -Force
    Write-Host ''
    Write-Host 'Client built and packaged successfully.' -ForegroundColor Green
    Write-Host $zip
    Write-Host 'Players extract the entire ZIP and open MetalSlugWarzone.Client.exe.'
}
catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
