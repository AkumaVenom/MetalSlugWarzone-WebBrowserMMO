$ErrorActionPreference = 'Stop'
$shell = $null
$shortcut = $null
try {
    $exe = Join-Path $PSScriptRoot 'MetalSlugWarzone.Client.exe'
    if (-not (Test-Path -LiteralPath $exe)) { throw 'Extract the entire player ZIP before creating a shortcut.' }
    $desktop = [Environment]::GetFolderPath('DesktopDirectory')
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path -LiteralPath $desktop -PathType Container)) {
        throw 'Your Desktop is unavailable. You can still open MetalSlugWarzone.Client.exe directly.'
    }
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path $desktop 'Metal Slug Warzone Client.lnk'))
    $shortcut.TargetPath = $exe
    $shortcut.WorkingDirectory = $PSScriptRoot
    $shortcut.IconLocation = $exe + ',0'
    $shortcut.Description = 'Play Metal Slug Warzone.'
    $shortcut.Save()
    Write-Host 'Your Metal Slug Warzone Client desktop shortcut is ready.' -ForegroundColor Green
    Write-Host 'Keep this extracted folder in place; the shortcut opens the client from here.'
}
catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
finally {
    if ($null -ne $shortcut) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut) }
    if ($null -ne $shell) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) }
}
